// Clãs e territórios (etapa 7). Toda ação é conferida no banco.
import * as rede from './rede.js';

const $ = (id) => document.getElementById(id);
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const num = (n) => Number(n || 0).toLocaleString('pt-BR');
const CORES = ['#c43b3b', '#3b6fd2', '#2f9e5b', '#c98a1c', '#8a3bc4', '#2a2f3a'];

let ctx = null;
let aberta = false;

export function iniciarCla(contexto) {
  ctx = contexto;
  $('btCla').onclick = abrir;
  $('fecharCla').onclick = fechar;
}
export function abrir() { aberta = true; $('claJanela').classList.remove('oculto'); desenhar(); }
function fechar() { aberta = false; $('claJanela').classList.add('oculto'); }
export function atualizarCla() { if (aberta) desenhar(); }

function msg(t, ok = true) { const m = $('claMsg'); m.textContent = t; m.className = 'msg ' + (ok ? 'ok' : 'erro'); clearTimeout(msg.t); msg.t = setTimeout(() => { m.textContent = ''; }, 4000); }
async function executar(fn, sucesso) {
  try { const r = await fn(); msg(typeof sucesso === 'function' ? sucesso(r) : sucesso); ctx.recarregar(); await desenhar(); }
  catch (e) { msg(e.message, false); }
}
const inteiro = (id) => Math.floor(Number($(id)?.value) || 0);

async function desenhar() {
  const c = $('claConteudo');
  try {
    const eu = ctx.perfil().id;
    const [clas, meuId, territorios] = await Promise.all([rede.listarClas(), rede.meuClaId(eu), rede.listarTerritorios()]);
    ctx.definirCla(meuId, clas.find((x) => x.id === meuId) || null);
    const meu = clas.find((x) => x.id === meuId);
    const nomeCla = (id) => clas.find((x) => x.id === id)?.nome;
    if (!meu) {
      $('claTitulo').textContent = 'Clãs';
      c.innerHTML = `<p class="dica">Clãs disputam territórios (cada um rende <b>400 moedas por hora</b> ao caixa do clã), roubam cargas e guardam o que roubaram. Policiais não podem estar em clã.</p>
        <div class="sub">Fundar um clã (5.000 moedas)</div>
        <div class="form"><label>Nome <input id="cNomeCla" maxlength="20" placeholder="Ex.: Lobos do Deserto"></label>
          <label>Cor <select id="cCor">${CORES.map((k, i) => `<option value="${k}">${['Vermelho', 'Azul', 'Verde', 'Laranja', 'Roxo', 'Preto'][i]}</option>`).join('')}</select></label>
          <button id="cCriar">Fundar clã</button></div>
        <div class="sub">Clãs da cidade</div>
        <div class="lista">${clas.length ? clas.map((x) => `<div class="linha"><b style="color:${esc(x.cor)}">■</b> <b>${esc(x.nome)}</b><br><small>Líder: ${esc(x.lider_perfil?.nome)} · ${territorios.filter((t) => t.dono_cla === x.id).length} território(s)</small></div>`).join('') : '<span class="vazio">Nenhum clã ainda.</span>'}</div>
        <p class="dica">Para entrar num clã existente, peça ao líder que adicione você pelo nome.</p>`;
      $('cCriar').onclick = () => executar(() => rede.cla.criar($('cNomeCla').value.trim(), $('cCor').value), 'Clã fundado!');
      return;
    }
    const lider = meu.lider === eu;
    const membros = await rede.membrosDoCla(meu.id);
    $('claTitulo').textContent = meu.nome;
    c.innerHTML = `<div class="cartoes"><div><small>Caixa</small><b>${num(meu.caixa)}</b></div><div><small>Robôs livres</small><b>${meu.robos}</b></div>
        <div><small>Chocolate roubado</small><b>${meu.chocolate}</b></div><div><small>Remédio roubado</small><b>${meu.remedio}</b></div></div>
      <div class="sub">Caixa do clã</div>
      <div class="botoes"><input id="clValor" type="number" min="1" placeholder="Valor" inputmode="numeric"><button id="clDep">Depositar</button>${lider ? '<button id="clSaq">Sacar</button>' : ''}</div>
      <div class="sub">Estoque roubado</div>
      <div class="botoes"><button data-ret="chocolate">Pegar 1 chocolate</button><button data-ret="remedio">Pegar 1 remédio</button>
        ${lider ? '<button data-vend="chocolate">Vender chocolates</button><button data-vend="remedio">Vender remédios</button>' : ''}</div>
      <div class="sub">Territórios</div>
      <div class="lista">${territorios.map((t) => `<div class="linha"><b>${esc(t.nome)}</b> <small>${t.dono_cla ? 'do ' + esc(nomeCla(t.dono_cla) || '?') : 'livre'} · defesa: ${t.dono_cla === meu.id ? t.defesa + ' robôs' : (t.defesa ? 'há robôs' : 'nenhuma')}</small>
        ${lider ? `<span class="bts">${t.dono_cla === meu.id
          ? `<button data-def="${t.id}" data-n="1">+1 robô na defesa</button><button data-def="${t.id}" data-n="-1">Recolher 1</button>`
          : `<button data-atk="${t.id}">Atacar com robôs</button>`}</span>` : ''}</div>`).join('')}</div>
      <p class="dica">Para tomar um território, fique com o clã dentro do círculo dele: 60 s, mais 20 s por robô defensor. ${lider ? 'Ou ataque com robôs: vence quem tiver mais força (defensores valem 30% a mais).' : ''}</p>
      ${lider ? `<div class="botoes"><input id="clAtkN" type="number" min="1" value="${Math.max(1, meu.robos)}" inputmode="numeric"><button id="clRobo">Comprar robô (8.000 do caixa)</button></div>` : ''}
      <div class="sub">Membros (${membros.length}/15)</div>
      ${lider ? '<div class="botoes"><input id="clNome" placeholder="Nome do jogador"><button id="clAdd">Adicionar</button></div>' : ''}
      <div class="lista">${membros.map((m) => `<div class="linha item"><span class="nm"><b>${esc(m.perfil?.nome)}</b><small>${m.jogador === meu.lider ? 'líder' : 'membro'}</small></span>
        <span class="bts">${lider && m.jogador !== meu.lider ? `<button data-exp="${m.jogador}">Expulsar</button>` : ''}</span></div>`).join('')}</div>
      <div class="botoes" style="margin-top:12px"><button id="clSair" class="perigo">Sair do clã</button></div>`;
    const on = (id, fn) => { const b = $(id); if (b) b.onclick = fn; };
    on('clDep', () => { const v = inteiro('clValor'); if (v > 0) executar(() => rede.cla.depositar(v), `Depositado: ${num(v)}.`); });
    on('clSaq', () => { const v = inteiro('clValor'); if (v > 0) executar(() => rede.cla.sacar(v), `Sacado: ${num(v)}.`); });
    on('clRobo', () => executar(() => rede.cla.comprarRobo(), 'Robô de combate comprado.'));
    on('clAdd', () => { const n = $('clNome').value.trim(); if (n) executar(() => rede.cla.adicionar(n), `${n} entrou no clã.`); });
    on('clSair', () => { const b = $('clSair'); if (!b.dataset.conf) { b.dataset.conf = '1'; b.textContent = 'Toque de novo para sair'; return; } executar(() => rede.cla.sair(), 'Você saiu do clã.'); });
    c.querySelectorAll('[data-ret]').forEach((b) => { b.onclick = () => executar(() => rede.cla.retirar(b.dataset.ret, 1), 'Item na sua mochila.'); });
    c.querySelectorAll('[data-vend]').forEach((b) => { b.onclick = () => { const q = meu[b.dataset.vend]; if (q > 0) executar(() => rede.cla.vender(b.dataset.vend, q), (r) => `Vendido por ${num(r)} (caixa do clã).`); else msg('Nada para vender.', false); }; });
    c.querySelectorAll('[data-exp]').forEach((b) => { b.onclick = () => executar(() => rede.cla.expulsar(b.dataset.exp), 'Membro expulso.'); });
    c.querySelectorAll('[data-def]').forEach((b) => { b.onclick = () => executar(() => rede.cla.defender(b.dataset.def, Number(b.dataset.n)), 'Defesa atualizada.'); });
    c.querySelectorAll('[data-atk]').forEach((b) => {
      b.onclick = () => { const n = inteiro('clAtkN'); if (n < 1) { msg('Escolha quantos robôs.', false); return; }
        executar(() => rede.cla.atacar(b.dataset.atk, n), (r) => r.startsWith('vitoria') ? `Vitória! O território é seu, com ${r.split(':')[1]} robôs na defesa.` : 'Derrota: os robôs foram destruídos.'); };
    });
  } catch (e) { c.textContent = e.message; }
}
