// Metrópole em volta do centro, horizonte de prédios e as cidades vizinhas (Vila Serra e Porto Sul).
// Tudo é gerado por código e desenhado com InstancedMesh para rodar leve no celular.
import * as THREE from 'three';
import { CIDADE } from './config.js';

const { quarteiroes: N, quarteirao: QB, rua: RW, calcada: CW } = CIDADE;
export const PASSO = QB + RW;
const TOTAL = N * QB + (N + 1) * RW, METADE = TOTAL / 2;
export const ruaC = (i) => -METADE + RW / 2 + i * PASSO;
export const quadC = (i) => -METADE + RW + QB / 2 + i * PASSO;
export const LIM = ruaC(10) - 2;              // 430: até onde se anda na metrópole
const BORDA = ruaC(10) + RW / 2;              // 437
export const CORREDOR = ruaC(3) - RW / 2;     // 49: meia largura da faixa da ferrovia
const MI = -6, MA = 9;                        // índices dos quarteirões da metrópole
const SI = -10, SA = 13;                      // índices do horizonte de prédios
export const FIM_HORIZONTE = quadC(SA) + QB / 2;   // ~643

// as cidades vizinhas ficam no fim de cada linha de trem
export const CIDADES = [
  { id: 'norte', nome: 'Vila Serra', s: -1 },
  { id: 'sul', nome: 'Porto Sul', s: 1 },
];
const CID = { ruas: [945, 999, 1053, 1107], colunas: [-81, -27, 27, 81], blocos: [972, 1026, 1080], xs: [-54, 0, 54] };
export const CIDADE_Z = { min: 900, max: 1390, maxSul: 1108, x: 300 };   // cidade + a mata em volta (+ o morro da Serra)
// Morro da Serra: começa depois da mata de Vila Serra (z < -1150) e sobe até ~50 m. Dá para subir a pé ou de carro.
export function morro(x, z) {
  if (z > -1150) return 0;
  const t = Math.min(1, (-z - 1150) / 230), base = t * t * (3 - 2 * t);
  const ondas = 0.78 + 0.14 * Math.sin(x / 47) + 0.08 * Math.sin(x / 19 + z / 31);
  const picos = 10 * Math.exp(-((x + 120) ** 2 + (z + 1330) ** 2) / 5000) + 8 * Math.exp(-((x - 150) ** 2 + (z + 1300) ** 2) / 4000);
  const mar = 1 - THREE.MathUtils.smoothstep(-z, 1440, 1528);   // depois do topo, a encosta desce até o mar do norte
  return (base * 46 * ondas + picos * base) * mar;
}
// ---------------------------------------------------------------- FAVELAS (morros com casas prontas, ruas, ônibus e base de clã no alto)
// Morro da Serra (atrás de Vila Serra) e Morro do Porto (litoral leste, ao lado da Base Naval, com vista para o mar).
export const FAVELAS = {
  serra: { nome: 'Favela do Morro da Serra', x0: -128, x1: 128, z0: -1386, z1: -1142, base: { x: 0, z: -1362, w: 50, d: 44 }, entrada: { x: 0, z: -1150 } },
  porto: { nome: 'Favela do Morro do Porto', x0: 914, x1: 1094, z0: 954, z1: 1107, base: { x: 1050, z: 1085, w: 50, d: 38 }, entrada: { x: 1050, z: 958 } },
};
// relevo do Morro do Porto: sobe da rua (norte) e da Base Naval (oeste) até o paredão sobre o mar (sul e leste)
export function morroPorto(x, z) {
  if (x < 900 || x > 1100 || z < 948 || z > 1112) return 0;
  const sx = THREE.MathUtils.smoothstep(x, 912, 1030), sz = THREE.MathUtils.smoothstep(z, 952, 1068);
  return 34 * sx * sz * (0.86 + 0.09 * Math.sin(x / 23) + 0.05 * Math.sin(z / 17 + x / 41));
}   // cidade + a mata em volta
// Quartel do Exército (Porto Sul, na mata a leste da cidade): muro, portão a oeste, pátio no meio
// Base Aérea: ao lado do quartel (a leste), com pista ao longo de x. Acesso pela rua z = 945 (vinda da rodovia).
export const BASE_AEREA = { x0: 300, x1: 620, z0: 975, z1: 1105, portao: { x: 400, z: 975 }, pista: { x0: 330, x1: 610, z: 1080, larg: 20 } };
// Base Naval (Marinha): no litoral, a leste da Base Aérea. Porta-aviões e destróieres ancorados no mar (proa para o sul, +z).
export const BASE_NAVAL = { x0: 630, x1: 880, z0: 1000, z1: 1110, portao: { x: 755, z: 1000 },
  porta: { x: 760, z: 1270, comp: 200 }, destroieres: [{ x: 675, z: 1215, comp: 110 }, { x: 845, z: 1215, comp: 110 }] };
// passagem interna entre as bases (z de 1048 a 1060): muro leste do quartel, oeste e leste da Base Aérea e oeste da Naval
export const PASSAGEM_BASES = { z0: 1048, z1: 1060 };
// Área 51: base secreta do Exército no deserto, a oeste da metrópole (acesso pela Avenida Central, z = 0)
export const AREA51 = { x0: -880, x1: -700, z0: -110, z1: 110, portao: { x: -700, z: 0 }, hangar: { x: -800, z: -20, w: 34, d: 30 }, deserto: { x0: -900, x1: -640, z0: -260, z1: 260 } };
export const QUARTEL = { x0: 150, x1: 250, z0: 966, z1: 1104, portao: { x: 146, z: 1053 }, patio: { x: 190, z: 1026 } };

let ctx = null;
let s0 = 90210;
const rnd = () => (s0 = (s0 * 16807) % 2147483647) / 2147483647;
const entre = (a, b) => a + rnd() * (b - a);
const escolher = (a) => a[Math.floor(rnd() * a.length)];

const edificios = [];      // { x, z, w, d, h, y, cor, tipo, rot, telha, det:[] }
const detalhes = [];       // caixas no telhado: { ed, dx, dz, w, h, d }
const arvores = [];        // [x, z, escala]
export const PROPS = { banco: [], hidrante: [], semaforo: [] };
export const CRUZAMENTOS = [];   // { x, z }: semáforos funcionando (js/semaforos.js), um poste em cada esquina   // [x, z, ângulo] dos objetos de rua em 3D (GLB)
const calcadas = [];       // [x, z, w, d, y]
const gramados = [];       // [x, z, w, d]
const ruas = [];           // [x, z, w, d, vertical]
const extras = [];         // retângulos só para o minimapa: { x0, x1, z0, z1, cor }
const pisos = [];          // { x0, x1, z0, z1, h, rampa?: { eixo, de, ate, h0, h1 } }
const blocosMetro = new Set();
const grade = new Map(), gradeEd = new Map(); const CEL = 27;

// ---------------------------------------------------------------- colisão e altura
const chaves = (x0, z0, x1, z1) => {
  const r = [];
  for (let i = Math.floor(x0 / CEL); i <= Math.floor(x1 / CEL); i++) for (let j = Math.floor(z0 / CEL); j <= Math.floor(z1 / CEL); j++) r.push(i + ',' + j);
  return r;
};
// topo do prédio (ou casa/galpão) que cobre este ponto, em metros; 0 se não tem prédio (aviões e helicópteros)
export function topoPredio(x, z) {
  const l = gradeEd.get(Math.floor(x / CEL) + ',' + Math.floor(z / CEL)); if (!l) return 0;
  let h = 0;
  for (const i of l) { const e = edificios[i]; if (e && Math.abs(x - e.x) <= e.w / 2 && Math.abs(z - e.z) <= e.d / 2) h = Math.max(h, (e.y || 0) + e.h); }
  return h;
}
// telhado onde dá para pousar (pássaro e helicóptero): altura e se é laje plana (casa tem telhado inclinado)
export function tetoEm(x, z) {
  const l = gradeEd.get(Math.floor(x / CEL) + ',' + Math.floor(z / CEL)); if (!l) return null;
  let r = null;
  for (const i of l) {
    const e = edificios[i]; if (!e || e.removido || Math.abs(x - e.x) > e.w / 2 || Math.abs(z - e.z) > e.d / 2) continue;
    const casa = e.tipo === 'casa', h = (e.y || 0) + e.h + (casa ? 1.2 : 0.02);
    if (!r || h > r.h) r = { h, plano: !casa && e.w >= 6 && e.d >= 6 };
  }
  return r;
}
export function addCol(c) {
  const [x0, z0, x1, z1] = c.tipo === 'circ' ? [c.x - c.r, c.z - c.r, c.x + c.r, c.z + c.r] : [c.x0, c.z0, c.x1, c.z1];
  for (const k of chaves(x0, z0, x1, z1)) { if (!grade.has(k)) grade.set(k, []); grade.get(k).push(c); }
}
export function addPiso(p) { pisos.push(p); }
export function colidir(p, raio, resolverLista) {
  const vistos = new Set();
  for (const k of chaves(p.x - raio, p.z - raio, p.x + raio, p.z + raio)) {
    const l = grade.get(k); if (!l) continue;
    const novos = l.filter((c) => !vistos.has(c)); novos.forEach((c) => vistos.add(c));
    resolverLista(novos, p, raio);
  }
}
export function altura(x, z) { return alturaBase(x, z, true); }
// rua = false: o chão sem os 10 cm do asfalto das ruas dos morros (é sobre ele que o asfalto é desenhado)
function alturaBase(x, z, rua) {
  for (let k = pisos.length - 1; k >= 0; k--) {
    const p = pisos[k];
    if (x < p.x0 || x > p.x1 || z < p.z0 || z > p.z1) continue;
    if (!p.rampa) return p.h;
    const r = p.rampa, v = r.eixo === 'z' ? z : x;
    return THREE.MathUtils.lerp(r.h0, r.h1, THREE.MathUtils.clamp((v - r.de) / (r.ate - r.de), 0, 1)) + (rua && naRuaMorro(x, z) ? 0.1 : 0);   // a rampa é coberta pelo asfalto
  }
  const i = Math.round((x - quadC(0)) / PASSO), j = Math.round((z - quadC(0)) / PASSO);
  if (blocosMetro.has(i + ',' + j) && Math.abs(x - quadC(i)) < QB / 2 && Math.abs(z - quadC(j)) < QB / 2) return 0.18;
  if (z < -1150 || (x > 900 && x < 1100 && z > 948 && z < 1112)) return chaoDoMorro(x, z, rua);
  const hc = alturaNaCalcada(x, z);
  return rua && naRuaMorro(x, z) ? (hc ?? 0) + 0.1 : hc;   // ruas que levam às favelas (fora do relevo)
}
// chão dos morros igual ao que aparece na tela: o asfalto das ruas fica 10 cm acima do terreno e o gramado é uma malha
// de triângulos (10 m na Serra, 2,5 m no Porto) que corta as curvas do relevo; antes o pé afundava no meio dos triângulos
function chaoDoMorro(x, z, rua) {
  const serra = z < -1150, nat = serra ? morro(x, z) : morroPorto(x, z);
  if (!rua) return nat;
  if (naRuaMorro(x, z)) return nat + 0.1;
  return (serra ? naMalha(morro, 0, -1340, 900, 380, 90, 38, x, z) : naMalha(morroPorto, 1000, 1030, 200, 164, 80, 66, x, z)) ?? nat;
}
// dentro de uma favela (com a rua dela e um pouco de folga) ou numa rua de morro
function naFavela(x, z) {
  for (const f of Object.values(FAVELAS)) if (x > f.x0 - 4 && x < f.x1 + 4 && z > f.z0 - 4 && z < f.z1 + 4) return true;
  return naRuaMorro(x, z);
}
function naRuaMorro(x, z) {
  if (!((z < -1090 && z > -1400 && x > -175 && x < 175) || (z > 930 && z < 1112 && x > 80 && x < 1100))) return false;
  for (const [rx, rz, w, d, , desenhar] of ruasMorro) if (desenhar && Math.abs(x - rx) <= w / 2 && Math.abs(z - rz) <= d / 2) return true;
  return false;
}
function naMalha(fn, cx, cz, W, D, nx, nz, x, z) {   // altura no triângulo da PlaneGeometry (diagonal igual à do three.js)
  const sx = W / nx, sz = D / nz, x0 = cx - W / 2, z0 = cz - D / 2;
  const fi = (x - x0) / sx, fj = (z - z0) / sz;
  if (fi < 0 || fj < 0 || fi >= nx || fj >= nz) return null;
  const i = Math.floor(fi), j = Math.floor(fj), u = fi - i, v = fj - j;
  const xa = x0 + i * sx, za = z0 + j * sz, h = (a, b) => fn(xa + a * sx, za + b * sz) + 0.05;
  if (u + v <= 1) { const ha = h(0, 0); return ha + u * (h(1, 0) - ha) + v * (h(0, 1) - ha); }
  const hc = h(1, 1); return hc + (1 - u) * (h(0, 1) - hc) + (1 - v) * (h(1, 0) - hc);
}
// calçadas fora do centro (cidades vizinhas, bairros novos, quartel): o chão sobe junto com a calçada desenhada
// (antes só o centro sabia a altura e o personagem afundava 18 cm nelas)
let gradeCalc = null, nCalc = -1;
function alturaNaCalcada(x, z) {
  if (nCalc !== calcadas.length) {
    nCalc = calcadas.length; gradeCalc = new Map();
    calcadas.forEach(([cx, cz, w, d], k) => { for (const c of chaves(cx - w / 2, cz - d / 2, cx + w / 2, cz + d / 2)) { if (!gradeCalc.has(c)) gradeCalc.set(c, []); gradeCalc.get(c).push(k); } });
  }
  const l = gradeCalc.get(Math.floor(x / CEL) + ',' + Math.floor(z / CEL)); if (!l) return null;
  let h = null;
  for (const k of l) { const [cx, cz, w, d, y] = calcadas[k]; if (Math.abs(x - cx) <= w / 2 && Math.abs(z - cz) <= d / 2) h = Math.max(h ?? 0, y); }
  return h;
}
// mantém o jogador nas áreas andáveis (a ferrovia só se cruza de trem)
// partes do porto por onde se anda no mar: píer, rampa de embarque e convés do navio
export const AREAS_NAVIO = [{ x0: 43.6, x1: 52.4, z0: 1100, z1: 1182 }, { x0: 52, x1: 60, z0: 1149.5, z1: 1153.5 }, { x0: 59.4, x1: 72.6, z0: 1131, z1: 1189 }];
export function limitar(p) {
  if (p.x > 1500) return;                                   // interiores das casas
  if (p.z > CIDADE_Z.maxSul && p.z < 1200 && p.x > 30 && p.x < 80) {   // píer, rampa e convés do cargueiro
    let melhor = null, md = Infinity;
    for (const r of AREAS_NAVIO) {
      const x = THREE.MathUtils.clamp(p.x, r.x0, r.x1), z = THREE.MathUtils.clamp(p.z, r.z0, r.z1), d = Math.hypot(x - p.x, z - p.z);
      if (d < md) { md = d; melhor = [x, z]; }
    }
    if (md < 3) { p.x = melhor[0]; p.z = melhor[1]; return; }
  }
  if (p.x >= 110 && p.x <= 530 && p.z >= -880 && p.z <= -650) return;   // Aeroporto da Metrópole
  if (p.x >= 880 && p.x <= 1096 && p.z >= 912 && p.z <= 1108) return;    // Favela do Morro do Porto e os lotes da rua dela
  if (p.z > BASE_NAVAL.z1 - 4 && p.z < 1175 && p.x > BASE_NAVAL.x0 - 5 && p.x < BASE_NAVAL.x1 + 5) {   // cais e píeres da Base Naval
    const areas = [{ x0: BASE_NAVAL.x0, x1: BASE_NAVAL.x1, z0: BASE_NAVAL.z1 - 4, z1: 1114 }, ...[675, 760, 845].map((x) => ({ x0: x - 3.6, x1: x + 3.6, z0: 1110, z1: 1167.5 }))];
    let melhor = null, md = Infinity;
    for (const r of areas) { const x = THREE.MathUtils.clamp(p.x, r.x0, r.x1), z = THREE.MathUtils.clamp(p.z, r.z0, r.z1), d = Math.hypot(x - p.x, z - p.z); if (d < md) { md = d; melhor = [x, z]; } }
    p.x = melhor[0]; p.z = melhor[1]; return;
  }
  if (p.x >= 250 && p.x <= BASE_NAVAL.x1 + 10 && p.z >= 938 && p.z <= BASE_NAVAL.z1 + 2) return;   // Base Aérea, Base Naval, o campo em volta e a rua até os portões
  if (p.x >= AREA51.x0 - 15 && p.x <= -630 && p.z >= AREA51.z0 - 15 && p.z <= AREA51.z1 + 15) { p.x = Math.max(p.x, AREA51.x0 + 1); p.z = THREE.MathUtils.clamp(p.z, AREA51.z0 + 1, AREA51.z1 - 1); return; }   // deserto da Área 51 e a estrada até ela
  if (p.x >= 157 && p.x <= 167 && p.z >= -662 && p.z <= -630) return;   // acesso ao aeroporto
  if (p.x >= -167 && p.x <= -157 && p.z >= -950 && p.z <= -636) return;   // rodovia para Vila Serra
  if (p.x >= 211 && p.x <= 221 && p.z >= 636 && p.z <= 950) return;     // rodovia para Porto Sul
  if (Math.abs(p.z) > 700) {
    const s = Math.sign(p.z);
    p.x = THREE.MathUtils.clamp(p.x, -CIDADE_Z.x, CIDADE_Z.x);
    const a = Math.abs(THREE.MathUtils.clamp(Math.abs(p.z), CIDADE_Z.min, s > 0 ? CIDADE_Z.maxSul : CIDADE_Z.max));
    p.z = s * a; return;
  }
  if (Math.abs(p.x) <= LIM && Math.abs(p.z) <= LIM) return;
  if (ruaHorizonte(p.x, p.z)) return;
  // fora: volta para o ponto válido mais perto (borda da metrópole ou a rua do horizonte mais próxima)
  const HL = FIM_HORIZONTE - 3, m = RW / 2 - 0.7, cands = [[THREE.MathUtils.clamp(p.x, -LIM, LIM), THREE.MathUtils.clamp(p.z, -LIM, LIM)]];
  const iX = Math.round((p.x - ruaC(0)) / PASSO), iZ = Math.round((p.z - ruaC(0)) / PASSO);
  for (const i of [iX - 1, iX, iX + 1]) { const c = ruaC(i); cands.push([THREE.MathUtils.clamp(p.x, c - m, c + m), THREE.MathUtils.clamp(p.z, -HL, HL)]); }
  for (const j of [iZ - 1, iZ, iZ + 1]) { const c = ruaC(j); cands.push([THREE.MathUtils.clamp(p.x, -HL, HL), THREE.MathUtils.clamp(p.z, c - m, c + m)]); }
  let melhor = cands[0], md = Infinity;
  for (const [x, z] of cands) {
    if (!((Math.abs(x) <= LIM && Math.abs(z) <= LIM) || ruaHorizonte(x, z))) continue;
    const d = Math.hypot(x - p.x, z - p.z); if (d < md) { md = d; melhor = [x, z]; }
  }
  p.x = melhor[0]; p.z = melhor[1];
}
// está numa rua do horizonte de prédios? (fora da ferrovia)
function ruaHorizonte(x, z) {
  const HL = FIM_HORIZONTE - 3, m = RW / 2 - 0.6;
  if (Math.abs(x) > HL || Math.abs(z) > HL) return false;
  if (Math.abs(z) > BORDA - 3 && Math.abs(x) < CORREDOR) return false;
  // antes só a faixa do asfalto era permitida e a calçada/quarteirão em volta "batia" como parede (perto do Aeroporto
  // e da Área 51); agora anda-se no quarteirão todo e só os prédios (que ganharam colisão) seguram
  void m; return true;
}

// ---------------------------------------------------------------- materiais
export const UNI = { uNoite: { value: 0 }, uTerreo: { value: null } };
function materialMundo(params, modo, esc = [4, 3.5]) {
  const m = new THREE.MeshStandardMaterial(params);
  m.onBeforeCompile = (sh) => {
    sh.uniforms.uNoite = UNI.uNoite; sh.uniforms.uTerreo = UNI.uTerreo;
    sh.vertexShader = sh.vertexShader.replace('#include <common>', `#include <common>
varying float vTopo; varying float vAlt; varying float vLoja;
${modo === 'fachada' ? 'attribute float aLoja;' : ''}`)
      .replace('#include <project_vertex>', `#include <project_vertex>
  {
    mat4 mM = modelMatrix;
    #ifdef USE_INSTANCING
    mM = modelMatrix * instanceMatrix;
    #endif
    vec4 wp = mM * vec4(transformed, 1.0);
    vec3 wn = normalize(mat3(mM) * objectNormal);
    vTopo = step(0.5, wn.y);
    vAlt = wp.y;
    vLoja = ${modo === 'fachada' ? 'aLoja' : '0.0'};
    #ifdef USE_MAP
    vMapUv = ${modo === 'fachada' ? '(abs(wn.x) > 0.5 ? vec2(wp.z, wp.y) : vec2(wp.x, wp.y))' : 'wp.xz'} / vec2(${esc[0].toFixed(2)}, ${esc[1].toFixed(2)});
    #endif
  }`);
    if (modo === 'fachada') {
      sh.fragmentShader = sh.fragmentShader.replace('#include <common>', `#include <common>
varying float vTopo; varying float vAlt; varying float vLoja;
uniform float uNoite; uniform sampler2D uTerreo;`)
        .replace('#include <color_fragment>', `#include <color_fragment>
  if (vTopo > 0.5) diffuseColor.rgb = vec3(0.33, 0.32, 0.31);
  // térreo com vitrines nos prédios
  float terreoF = (1.0 - vTopo) * vLoja * step(vAlt, 3.55);
  vec4 terreoTex = vec4(0.0);
  if (terreoF > 0.5) {
    terreoTex = texture2D(uTerreo, vMapUv);
    vec3 tinta = vec3(1.0);
    #ifdef USE_INSTANCING_COLOR
    tinta = mix(vec3(1.0), vColor, 0.45);
    #endif
    diffuseColor.rgb = terreoTex.rgb * tinta;
  }`)
        .replace('#include <emissivemap_fragment>', `#include <emissivemap_fragment>
  {
    // à noite parte das janelas acende (cada janela sorteia a sua)
    vec4 base = terreoF > 0.5 ? terreoTex : sampledDiffuseColor;
    float jan = smoothstep(0.04, 0.12, base.b - base.r) * (1.0 - vTopo);
    float h = fract(sin(dot(floor(vMapUv), vec2(12.9898, 78.233))) * 43758.5453);
    // vitrines: só parte acende e bem mais fraca (antes todas brilhavam forte e ofuscavam quem passava na rua)
    float acesa = terreoF > 0.5 ? step(0.4, h) : step(0.45, h);
    vec3 cor = terreoF > 0.5 ? vec3(1.0, 0.72, 0.4) : mix(vec3(1.0, 0.76, 0.42), vec3(0.72, 0.84, 1.0), step(0.86, h));
    totalEmissiveRadiance += jan * acesa * uNoite * cor * (terreoF > 0.5 ? 0.45 : 0.7);
  }`);
    }
  };
  m.customProgramCacheKey = () => `mundo2-${modo}-${esc.join('x')}`;
  return m;
}

let MAT = null;
function criarMateriais() {
  const T = ctx.texturaCanvas, R = ctx.ruido;
  const fachada = T(128, (g, t) => {
    g.fillStyle = '#f3efe6'; g.fillRect(0, 0, t, t); R(g, t, 1400, 0.05, 1.2);
    const gx = t * 0.2, gy = t * 0.22, gw = t * 0.6, gh = t * 0.52;
    g.fillStyle = '#d6cfc1'; g.fillRect(gx - 5, gy - 5, gw + 10, gh + 10);
    const gr = g.createLinearGradient(0, gy, 0, gy + gh); gr.addColorStop(0, '#46637e'); gr.addColorStop(1, '#1c2a38');
    g.fillStyle = gr; g.fillRect(gx, gy, gw, gh);
    g.fillStyle = 'rgba(255,255,255,.16)'; g.beginPath(); g.moveTo(gx, gy + gh * 0.65); g.lineTo(gx + gw * 0.42, gy); g.lineTo(gx + gw * 0.6, gy); g.lineTo(gx, gy + gh); g.fill();
    g.fillStyle = '#c9c0ae'; g.fillRect(gx, gy + gh * 0.48, gw, 3);
    g.fillStyle = '#bdb4a2'; g.fillRect(gx - 7, gy + gh + 3, gw + 14, 6);
    g.fillStyle = 'rgba(0,0,0,.10)'; g.fillRect(0, t - 4, t, 4);
  });
  const calcada = T(512, desenharCalcada);
  UNI.uTerreo.value = T(128, (g, t) => {
    g.fillStyle = '#e6e1d8'; g.fillRect(0, 0, t, t);
    g.fillStyle = '#3a3f46'; g.fillRect(0, 0, t, t * 0.16);                 // faixa do letreiro
    g.fillStyle = '#d8d1c4'; g.fillRect(0, t * 0.16, t, 4);
    const gr = g.createLinearGradient(0, t * 0.22, 0, t * 0.94); gr.addColorStop(0, '#5b7d99'); gr.addColorStop(1, '#22323f');
    g.fillStyle = gr; g.fillRect(t * 0.06, t * 0.22, t * 0.88, t * 0.72);
    g.fillStyle = 'rgba(255,255,255,.18)'; g.beginPath(); g.moveTo(t * 0.06, t * 0.7); g.lineTo(t * 0.4, t * 0.22); g.lineTo(t * 0.55, t * 0.22); g.lineTo(t * 0.06, t * 0.9); g.fill();
    g.fillStyle = '#c9c2b4'; g.fillRect(t * 0.48, t * 0.22, 5, t * 0.72);   // montante
    g.fillStyle = '#9c968c'; g.fillRect(0, t * 0.94, t, t * 0.06);           // rodapé
  });
  const ondas = T(256, (g, t) => {
    const img = g.createImageData(t, t);
    const alt = (x, y) => Math.sin(x * 0.11 + Math.sin(y * 0.07) * 2) * 0.5 + Math.sin(y * 0.19 + x * 0.05) * 0.35 + Math.sin((x + y) * 0.31) * 0.15;
    for (let y = 0; y < t; y++) for (let x = 0; x < t; x++) {
      const dx = alt(x + 1, y) - alt(x - 1, y), dy = alt(x, y + 1) - alt(x, y - 1), i = (y * t + x) * 4;
      img.data[i] = 128 + dx * 90; img.data[i + 1] = 128 + dy * 90; img.data[i + 2] = 255; img.data[i + 3] = 255;
    }
    g.putImageData(img, 0, 0);
  });
  ondas.colorSpace = THREE.NoColorSpace; ondas.repeat.set(60, 25);
  const grama = T(512, (g, t) => desenharGrama(g, t));
  const campo = T(512, (g, t) => desenharGrama(g, t, [132, 168, 92]));
  const asfalto = T(256, (g, t) => {
    g.fillStyle = '#41454d'; g.fillRect(0, 0, t, t); R(g, t, 9000, 0.06, 1.6);
  });
  MAT = {
    fachada: materialMundo({ map: fachada, roughness: 0.85, metalness: 0.05 }, 'fachada'),
    calcada: materialMundo({ map: calcada, roughness: 0.92 }, 'topo', [3.2, 3.2]),
    grama: materialMundo({ map: grama, roughness: 1 }, 'topo', [9, 9]),
    campo: materialMundo({ map: campo, roughness: 1 }, 'topo', [16, 16]),
    asfalto: materialMundo({ map: asfalto, roughness: 0.88 }, 'topo', [7, 7]),
    telha: new THREE.MeshStandardMaterial({ color: '#ffffff', roughness: 0.8 }),
    detalhe: new THREE.MeshStandardMaterial({ color: '#9da3a8', roughness: 0.7, metalness: 0.2 }),
    tronco: new THREE.MeshStandardMaterial({ color: '#6b4a2e', roughness: 0.9 }),
    copa: new THREE.MeshStandardMaterial({ color: '#ffffff', roughness: 0.85, flatShading: true, vertexColors: true }),
    chaoHorizonte: new THREE.MeshStandardMaterial({ color: '#5b5e64', roughness: 0.95 }),
    agua: new THREE.MeshStandardMaterial({ color: '#3e7ea6', roughness: 0.12, metalness: 0.25, normalMap: ondas, normalScale: new THREE.Vector2(0.6, 0.6) }),
    concreto: new THREE.MeshStandardMaterial({ color: '#b9b3a7', roughness: 0.9 }),
    morro: new THREE.MeshStandardMaterial({ color: '#7d8f63', roughness: 1, flatShading: true }),
  };
  return MAT;
}
export const materiais = () => MAT;


// ---------------------------------------------------------------- texturas compartilhadas (centro e metrópole)
const _a = (a, b) => a + Math.random() * (b - a);
// Calçada de pavers retangulares em junta amarrada, com variação de cor, rejunte e desgaste.
export function desenharCalcada(g, t) {
  g.fillStyle = '#8f877a'; g.fillRect(0, 0, t, t);                       // rejunte
  const linhas = 8, alt = t / linhas, larg = t / 4, j = 2;
  for (let r = 0; r < linhas; r++) {
    const off = (r % 2) * larg / 2;
    for (let c = -1; c < 5; c++) {
      const x = c * larg + off, y = r * alt;
      const v = _a(186, 214), q = _a(-6, 6);
      g.fillStyle = `rgb(${v + 8 + q | 0},${v + q | 0},${v - 14 | 0})`;
      g.fillRect(x + j / 2, y + j / 2, larg - j, alt - j);
      g.fillStyle = 'rgba(255,255,255,.10)'; g.fillRect(x + j / 2, y + j / 2, larg - j, 2);          // borda clara
      g.fillStyle = 'rgba(0,0,0,.10)'; g.fillRect(x + j / 2, y + alt - j / 2 - 2, larg - j, 2);      // borda escura
    }
  }
  for (let i = 0; i < 6000; i++) { g.fillStyle = Math.random() < 0.5 ? `rgba(255,255,255,${_a(0, 0.07)})` : `rgba(40,30,20,${_a(0, 0.08)})`; g.fillRect(_a(0, t), _a(0, t), 1.4, 1.4); }
  for (let i = 0; i < 7; i++) {                                           // manchas de uso
    const x = _a(0, t), y = _a(0, t), r = _a(10, 34), gr = g.createRadialGradient(x, y, 0, x, y, r);
    gr.addColorStop(0, `rgba(70,60,50,${_a(0.05, 0.12)})`); gr.addColorStop(1, 'rgba(70,60,50,0)');
    g.fillStyle = gr; g.fillRect(x - r, y - r, r * 2, r * 2);
  }
}
// Grama com manchas de tom, fiapos e florzinhas.
export function desenharGrama(g, t, base = [118, 160, 84]) {
  g.fillStyle = `rgb(${base})`; g.fillRect(0, 0, t, t);
  for (let i = 0; i < 40; i++) {
    const x = _a(0, t), y = _a(0, t), r = _a(20, 70), d = _a(-22, 18), gr = g.createRadialGradient(x, y, 0, x, y, r);
    const c = `${base[0] + d | 0},${base[1] + d * 1.1 | 0},${base[2] + d * 0.6 | 0}`;
    gr.addColorStop(0, `rgba(${c},.55)`); gr.addColorStop(1, `rgba(${c},0)`);
    for (const ox of [-t, 0, t]) for (const oy of [-t, 0, t]) { g.save(); g.translate(ox, oy); g.fillStyle = gr; g.fillRect(x - r, y - r, r * 2, r * 2); g.restore(); }
  }
  g.lineWidth = 1;
  for (let i = 0; i < 9000; i++) {
    const x = _a(0, t), y = _a(0, t), l = _a(1.5, 4), d = _a(-40, 40);
    g.strokeStyle = `rgba(${base[0] + d | 0},${base[1] + d + 15 | 0},${base[2] + d * 0.5 | 0},${_a(0.25, 0.6)})`;
    g.beginPath(); g.moveTo(x, y); g.lineTo(x + _a(-1, 1), y - l); g.stroke();
  }
  const flores = ['#f4f1e8', '#f2d34a', '#e8a6c8', '#c9b6f0'];
  for (let i = 0; i < 70; i++) { g.fillStyle = flores[i % 4]; g.fillRect(_a(0, t), _a(0, t), 2, 2); }
}

// Copa de árvore: vários blocos de icosaedro juntos, mais escura embaixo (cor por vértice × cor da instância).
function geoCopa(blocos) {
  const pos = [], cor = [];
  for (const [x, y, z, r] of blocos) {
    const g = new THREE.IcosahedronGeometry(r, 1); const p = g.attributes.position;
    for (let i = 0; i < p.count; i++) {
      // deforma um pouco para não parecer bola perfeita
      const px = p.getX(i), py = p.getY(i), pz = p.getZ(i), k = 1 + Math.sin(px * 3.1 + pz * 2.3 + py * 1.7) * 0.08;
      const X = x + px * k, Y = y + py * k, Z = z + pz * k; pos.push(X, Y, Z);
      const sombra = THREE.MathUtils.clamp(0.55 + (Y + 1.4) / 3.6 * 0.5, 0.55, 1.05); cor.push(sombra, sombra, sombra * 0.95);
    }
  }
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
  g.setAttribute('color', new THREE.Float32BufferAttribute(cor, 3));
  g.computeVertexNormals(); return g;
}
function geoPinheiro() {
  const pos = [], cor = [];
  for (const [y, r, h] of [[0.4, 1.35, 1.9], [1.3, 1.05, 1.6], [2.1, 0.72, 1.35]]) {
    const g = new THREE.ConeGeometry(r, h, 7).translate(0, y + h / 2, 0).toNonIndexed(); const p = g.attributes.position;
    for (let i = 0; i < p.count; i++) { const Y = p.getY(i); pos.push(p.getX(i), Y, p.getZ(i)); const s = THREE.MathUtils.clamp(0.55 + Y / 3.8 * 0.5, 0.55, 1.05); cor.push(s, s, s); }
  }
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
  g.setAttribute('color', new THREE.Float32BufferAttribute(cor, 3));
  g.computeVertexNormals(); return g;
}

// ---------------------------------------------------------------- peças
const CORES_PREDIO = ['#efe6d2', '#e4cfb0', '#d9b48f', '#c98f6a', '#bfc5c9', '#a9b8c8', '#e8d9a8', '#d7a39a', '#b7c4a3', '#f1f1ee', '#c7b9a6'];
const CORES_CASA = ['#f2e3c6', '#e9c9a8', '#cfe0e8', '#e7d2e0', '#f4efe4', '#d8e4c4', '#f0d39b'];
const CORES_TELHA = ['#a5502f', '#8c3f2a', '#9c5a3c', '#6b5145', '#4f5a63'];

export function predio(x, z, w, d, h, { y = 0.18, cor = escolher(CORES_PREDIO), colide = true, det = true, loja = true } = {}) {
  const i = edificios.length;
  edificios.push({ x, z, w, d, h, y, cor, tipo: 'predio', det: [], loja });
  if (colide) addCol({ tipo: 'caixa', x0: x - w / 2, x1: x + w / 2, z0: z - d / 2, z1: z + d / 2 });
  for (const k of chaves(x - w / 2, z - d / 2, x + w / 2, z + d / 2)) { if (!gradeEd.has(k)) gradeEd.set(k, []); gradeEd.get(k).push(i); }
  if (det && w > 8) {
    const n = Math.floor(rnd() * 3);
    for (let k = 0; k < n; k++) { edificios[i].det.push(detalhes.length); detalhes.push({ ed: i, dx: entre(-w / 3, w / 3), dz: entre(-d / 3, d / 3), w: entre(1.4, 3), h: entre(0.8, 2.2), d: entre(1.4, 3) }); }
  }
  return i;
}
function casa(x, z, w, d, andares, rot, y = 0.18) {
  const i = predio(x, z, w, d, andares * 3.2, { y, cor: escolher(CORES_CASA), det: false, loja: false });
  Object.assign(edificios[i], { tipo: 'casa', rot, telha: escolher(CORES_TELHA) });
  return i;
}
export function arvore(x, z, s = 1, colide = true) { const c = colide ? { tipo: 'circ', x, z, r: 0.5 * s } : null; arvores.push([x, z, s, c]); if (c) addCol(c); }
// abre uma trilha na mata: tira as árvores (e a colisão delas) a menos de "larg" metros dos segmentos [[x,z],[x,z],...]
export function abrirTrilha(pts, larg = 3) {
  const perto = (x, z) => { for (let i = 0; i < pts.length - 1; i++) { const [ax, az] = pts[i], [bx, bz] = pts[i + 1], dx = bx - ax, dz = bz - az, l2 = dx * dx + dz * dz || 1;
    const t = Math.max(0, Math.min(1, ((x - ax) * dx + (z - az) * dz) / l2)); if (Math.hypot(x - (ax + dx * t), z - (az + dz * t)) < larg) return true; } return false; };
  for (let k = arvores.length - 1; k >= 0; k--) {
    const [x, z, , c] = arvores[k];
    if (!perto(x, z)) continue;
    if (c) Object.assign(c, { x: 1e7, z: 1e7, r: 0 });
    arvores.splice(k, 1);
  }
}
// esvazia um retângulo antes de montar as malhas: árvores, arbustos, gramados e bancos (com a colisão deles)
export function limparArea(x0, z0, x1, z1) {
  const dentro = (x, z) => x >= x0 && x <= x1 && z >= z0 && z <= z1;
  for (let k = arvores.length - 1; k >= 0; k--) { const [x, z, , c] = arvores[k]; if (!dentro(x, z)) continue; if (c) Object.assign(c, { x: 1e7, z: 1e7, r: 0 }); arvores.splice(k, 1); }
  for (let k = arbustos.length - 1; k >= 0; k--) if (dentro(arbustos[k][0], arbustos[k][1])) arbustos.splice(k, 1);
  for (let k = gramados.length - 1; k >= 0; k--) if (dentro(gramados[k][0], gramados[k][1])) gramados.splice(k, 1);
  for (let k = PROPS.banco.length - 1; k >= 0; k--) {
    const [x, z] = PROPS.banco[k]; if (!dentro(x, z)) continue;
    for (const l of grade.values()) for (const c of l) if (c.tipo === 'circ' && c.x === x && c.z === z) Object.assign(c, { x: 1e7, z: 1e7, r: 0 });
    PROPS.banco.splice(k, 1);
  }
}
function rua(x, z, w, d) { ruas.push([x, z, w, d, d > w]); }
const ruasMorro = [];   // [x, z, w, d, vertical, desenhar]
export function listaRuasMorro() { return ruasMorro; }
function ruaMorro(x0, z0, x1, z1, desenhar = true) {   // de ponta a ponta, no eixo
  const vert = x0 === x1, w = vert ? RW : Math.abs(x1 - x0) + RW, d = vert ? Math.abs(z1 - z0) + RW : RW;
  ruasMorro.push([(x0 + x1) / 2, (z0 + z1) / 2, w, d, vert, desenhar]);
}

// um quarteirão de 44 m: calçada e o que tem em cima
function quadra(bx, bz, estilo, faixa = [2, 6], y = 0.18) {
  calcadas.push([bx, bz, QB, QB, y]);
  const meio = QB - CW * 2, L = meio / 2;
  if (estilo === 'parque') {
    gramados.push([bx, bz, meio, meio]);
    for (let k = 0; k < 8; k++) { const a = k / 8 * Math.PI * 2 + rnd() * 0.3; arvore(bx + Math.cos(a) * entre(9, 15), bz + Math.sin(a) * entre(9, 15), entre(0.9, 1.3)); }
    arvore(bx, bz, 1.5);
    for (let k = 0; k < 4; k++) {   // bancos de praça virados para a árvore do meio
      const a = k / 4 * Math.PI * 2 + Math.PI / 4, x = bx + Math.cos(a) * 5.2, z = bz + Math.sin(a) * 5.2;
      PROPS.banco.push([x, z, Math.atan2(bx - x, bz - z)]); addCol({ tipo: 'circ', x, z, r: 0.8 });
    }
    return;
  }
  if (estilo === 'torre') {
    const w = entre(26, 34), d = entre(26, 34);
    predio(bx, bz, w, d, Math.round(entre(10, 16)) * 3.5, { y });
    return;
  }
  if (estilo === 'casas') {
    const passo = meio / 3;
    for (let a = 0; a < 3; a++) for (let b = 0; b < 3; b++) {
      const cx = bx - meio / 2 + passo * (a + 0.5), cz = bz - meio / 2 + passo * (b + 0.5);
      if (a === 1 && b === 1) { arvore(cx, cz, 1.2); continue; }
      const w = entre(7, 9.5), d = entre(7, 9.5);
      casa(cx, cz, w, d, rnd() < 0.3 ? 2 : 1, rnd() < 0.5 ? 0 : Math.PI / 2, y);
      if (rnd() < 0.5) arvore(cx + (rnd() < 0.5 ? -1 : 1) * (passo / 2 - 1.2), cz + (rnd() < 0.5 ? -1 : 1) * (passo / 2 - 1.2), 0.8);
    }
    return;
  }
  if (estilo === 'galpoes') {
    for (const s of [-1, 1]) predio(bx, bz + s * L / 2, meio - 2, L * 0.85, entre(6.5, 9), { y, cor: escolher(['#b9c2c9', '#9fb0bf', '#c9b79c', '#a7a39b']), loja: false });   // dentro do quarteirão (antes invadiam a rua)
    return;
  }
  // 'predios': quatro lotes encostados na calçada
  for (const [sx, sz] of [[-1, -1], [1, -1], [-1, 1], [1, 1]]) {
    const w = entre(12, 17.5), d = entre(12, 17.5);
    const cx = bx + sx * (L / 2) + sx * ((L - w) / 2 - 0.4), cz = bz + sz * (L / 2) + sz * ((L - d) / 2 - 0.4);
    predio(cx, cz, w, d, Math.round(entre(faixa[0], faixa[1])) * 3.5, { y });
  }
}

// quarteirões com uso especial: prédios de apartamentos, loteamentos de terrenos e praças de território
const RESERVA = {
  '0,-1': { tipo: 'residencial', frente: 1, cor: '#d9c7b0' }, '3,4': { tipo: 'residencial', frente: -1, cor: '#c7d3dd' },
  '-1,0': { tipo: 'loteamento' }, '4,0': { tipo: 'loteamento' }, '-1,3': { tipo: 'loteamento' }, '4,3': { tipo: 'loteamento' },
  '-4,-4': { tipo: 'praca' }, '7,7': { tipo: 'praca' },
  '-1,-1': { tipo: 'vazio' }, '4,-1': { tipo: 'vazio' },          // prefeitura e concessionária
  '3,-1': { tipo: 'vazio' }, '-1,4': { tipo: 'vazio' }, '0,4': { tipo: 'vazio' },   // banco, hospital e bombeiros
  '4,4': { tipo: 'vazio' },                                         // cemitério
};
const extrasMesh = [];
function quadraEspecial(bx, bz, r) {
  calcadas.push([bx, bz, QB, QB, 0.18]);
  if (r.tipo === 'residencial') {
    const zc = bz - r.frente * 2;
    predio(bx, zc, 30, 24, 35, { cor: r.cor, loja: false });
    // marquise e portaria
    extrasMesh.push({ geo: [12, 0.3, 3], cor: '#2f3a44', pos: [bx, 3.6, zc + r.frente * 13.4] });
    extrasMesh.push({ geo: [5, 3.2, 0.2], cor: '#7fa6c2', pos: [bx, 1.8, zc + r.frente * 12.05], vidro: true });
    for (const sx of [-1, 1]) arvore(bx + sx * 9, zc + r.frente * 15.5, 0.8);
    return;
  }
  if (r.tipo === 'vazio') {   // prédio público: calçada com árvores nos cantos
    for (const sx of [-1, 1]) for (const sz of [-1, 1]) arvore(bx + sx * 19.5, bz + sz * 19.5, 0.9);
    return;
  }
  if (r.tipo === 'loteamento') {
    for (const sx of [-1, 1]) for (const sz of [-1, 1]) gramados.push([bx + sx * 9.5, bz + sz * 9.5, 17.6, 17.6]);
    return;
  }
  // praça do território: piso livre no meio, árvores só nos cantos
  for (const sx of [-1, 1]) for (const sz of [-1, 1]) arvore(bx + sx * 17.5, bz + sz * 17.5, 1.1);
}

function celulaMetro(i, j) {
  if (i >= 0 && i < N && j >= 0 && j < N) return false;                              // centro
  if ((i === -2 || i === -1 || i === N || i === N + 1) && (j === 1 || j === 2)) return false;   // territórios dos clãs
  if ((i === 1 || i === 2) && (j < 0 || j >= N)) return false;                       // corredor da ferrovia
  return true;
}

// ---------------------------------------------------------------- geração
function gerarMetropole() {
  for (let i = MI; i <= MA; i++) for (let j = MI; j <= MA; j++) {
    if (!celulaMetro(i, j)) continue;
    const x = quadC(i), z = quadC(j); blocosMetro.add(i + ',' + j);
    const res = RESERVA[i + ',' + j];
    if (res) { quadraEspecial(x, z, res); continue; }
    const d = Math.max(Math.abs(x), Math.abs(z)), r = rnd();
    let estilo = 'predios';
    if (r < 0.11) estilo = 'parque';
    else if (d > 300 && r < 0.62) estilo = 'casas';
    else if (d < 260 && r > 0.86) estilo = 'torre';
    quadra(x, z, estilo, d < 230 ? [2, 7] : [2, 5]);
  }
  // ruas: continuação das do centro e as novas
  const segs = (a, b, cortes) => {          // intervalo [a,b] menos os cortes
    let r = [[a, b]];
    for (const [c0, c1] of cortes) r = r.flatMap(([x0, x1]) => (c1 <= x0 || c0 >= x1 ? [[x0, x1]] : [[x0, c0], [c1, x1]].filter(([p, q]) => q - p > 1)));
    return r;
  };
  const terr = [METADE, -ruaC(-2) - RW / 2];      // 113 .. 211 em cada lado
  for (let i = MI; i <= MA + 1; i++) {
    const c = ruaC(i), noCentro = i >= 0 && i <= N;
    // horizontal (z = c)
    let cortes = noCentro ? [[-METADE, METADE]] : [[-CORREDOR, CORREDOR]];
    if (i === 2) cortes = cortes.concat([[-terr[1] - 5, -terr[0]], [terr[0], terr[1] + 5]]);
    for (const [a, b] of segs(-BORDA, BORDA, cortes)) rua((a + b) / 2, c, b - a, RW);
    // vertical (x = c)
    if (i === 2) continue;                        // a avenida do meio não atravessa a ferrovia
    let cv = noCentro ? [[-METADE, METADE]] : [];
    if (i === -1 || i === N + 1) cv = cv.concat([[ruaC(1), ruaC(3)]]);
    if (i === N + 1) cv = cv.concat([[-265, -221]]);   // x = 162: o trecho entre os dois quarteirões do terminal rodoviário vira parte dele
    for (const [a, b] of segs(-BORDA, BORDA, cv)) rua(c, (a + b) / 2, RW, b - a);
  }
}

function gerarHorizonte() {
  // ruas do horizonte: a metrópole continua por entre os prédios altos até o fim do mapa (sem cruzar a ferrovia)
  const H = FIM_HORIZONTE - 2;
  for (let i = SI + 1; i <= SA; i++) {
    const c = ruaC(i); if (Math.abs(c) > H) continue;
    if (Math.abs(c) <= BORDA) { if (Math.abs(c) >= CORREDOR) for (const s of [-1, 1]) rua(c, s * (BORDA + H) / 2, RW, H - BORDA); }
    else rua(c, 0, RW, 2 * H);
    if (Math.abs(c) <= BORDA) for (const s of [-1, 1]) rua(s * (BORDA + H) / 2, c, H - BORDA, RW);
    else for (const [a, b] of [[-H, -CORREDOR], [CORREDOR, H]]) rua((a + b) / 2, c, b - a, RW);
  }
  for (let i = SI; i <= SA; i++) for (let j = SI; j <= SA; j++) {
    if (i >= MI && i <= MA && j >= MI && j <= MA) continue;
    if (i === 1 || i === 2) continue;                               // corredor da ferrovia
    const x = quadC(i), z = quadC(j);
    if (rnd() < 0.45) predio(x, z, entre(24, 36), entre(24, 36), Math.round(entre(8, 24)) * 3.5, { y: 0 });
    else for (const [sx, sz] of [[-1, -1], [1, -1], [-1, 1], [1, 1]]) predio(x + sx * 11, z + sz * 11, entre(14, 18), entre(14, 18), Math.round(entre(5, 17)) * 3.5, { y: 0 });   // com colisão: dá para andar entre eles
  }
}

function gerarCidade(cid) {
  const s = cid.s;
  // ruas
  for (const z of CID.ruas) rua(0, s * z, 172, RW);
  for (const x of CID.colunas) rua(x, s * (CID.ruas[0] + CID.ruas[3]) / 2, RW, CID.ruas[3] - CID.ruas[0] + RW);
  // praça da estação
  calcadas.push([0, s * 934, 172, 12, 0.12]);
  pisos.push({ x0: -86, x1: 86, z0: s > 0 ? 928 : -940, z1: s > 0 ? 940 : -928, h: 0.12 });
  for (const bz of CID.blocos) for (const bx of CID.xs) {
    const x = bx, z = s * bz;
    pisos.push({ x0: x - QB / 2, x1: x + QB / 2, z0: z - QB / 2, z1: z + QB / 2, h: 0.18 });
    if (bx === 0 && bz === 1026) { quadra(x, z, 'parque'); continue; }
    if (bx === -54 && bz === 1080) { quadraEspecial(x, z, { tipo: 'praca' }); continue; }   // território da cidade
    // moradia: loteamentos (8 terrenos) e um prédio de 10 apartamentos virado para a estação
    if ((bx === -54 && bz === 972) || (bx === 54 && bz === 1080)) { quadraEspecial(x, z, { tipo: 'loteamento' }); continue; }
    if (bx === 0 && bz === 972) { quadraEspecial(x, z, { tipo: 'residencial', frente: -s, cor: cid.id === 'norte' ? '#d8cbb6' : '#bfd6dc' }); continue; }
    if (bx === 54 && bz === 972) { calcadas.push([x, z, QB, QB, 0.18]); cid.loja = { x: x - 6, z: z + (s > 0 ? -3 : 3) }; arvore(x + 12, z - 10); arvore(x + 12, z + 10); continue; }
    if (cid.id === 'norte') quadra(x, z, rnd() < 0.75 ? 'casas' : 'predios', [1, 3]);
    else quadra(x, z, bz === 1080 ? 'galpoes' : (rnd() < 0.5 ? 'predios' : 'casas'), [2, 4]);
  }
  // em volta: a mata (dá para andar nela; as árvores perto do caminho têm colisão)
  const Q = QUARTEL;
  for (let k = 0; k < (cid.id === 'norte' ? 560 : 420); k++) {
    const x = entre(-300, 300), z = s * entre(898, cid.id === 'norte' ? 1390 : 1240);
    if (Math.abs(x) < 95 && Math.abs(z) < 1118) continue;
    if (cid.id === 'sul' && Math.abs(z) > 1112) continue;
    if (Math.abs(x) < 50 && Math.abs(z) < 935) continue;
    if (cid.id === 'sul' && x > Q.x0 - 18 && x < Q.x1 + 18 && z > Q.z0 - 18 && z < Q.z1 + 18) continue;   // terreno do quartel
    if (cid.id === 'sul' && x > 80 && x < Q.x0 && Math.abs(z - Q.portao.z) < 9) continue;            // estrada do quartel
    const longe = Math.abs(x) > 300 || Math.abs(z) > 1392;
    arvore(x, z, entre(0.9, 1.7), !longe);
  }
  // arbustos baixos no chão da mata
  for (let k = 0; k < 160; k++) {
    const x = entre(-300, 300), z = s * entre(900, 1170);
    if (Math.abs(x) < 95 && Math.abs(z) < 1118) continue;
    if (cid.id === 'sul' && (Math.abs(z) > 1108 || (x > Q.x0 - 18 && x < Q.x1 + 18 && z > Q.z0 - 18 && z < Q.z1 + 18) || (x > 80 && x < Q.x0 && Math.abs(z - Q.portao.z) < 9))) continue;
    arbustos.push([x, z, entre(0.6, 1.3)]);
  }
  if (cid.id === 'sul') montarQuartel();
}
// ---------------------------------------------------------------- favelas: casas prontas no morro (ninguém constrói), becos, ruas no relevo
export const ILHA = { x0: -1000, x1: 1100, z0: -1528, z1: 1112 };   // a terra; em volta é mar
let s1 = 424242; const rf = () => (s1 = (s1 * 16807) % 2147483647) / 2147483647;   // sorteio próprio (não mexe no resto do mapa)
const CORES_FAVELA = ['#b5652f', '#a85a2a', '#c4703a', '#9c4f25', '#b86b3c', '#a4532b', '#d9cfc0', '#cfc6b4', '#e8c547', '#6fb1d6', '#e07a7a', '#8fcf8a', '#f0a35e', '#f2efe6', '#c9a0dc', '#7fc6b5'];
const chaoNatural = (x, z) => (z < -1150 ? morro(x, z) : morroPorto(x, z));
export const LOTES_FAVELA = [];   // centros dos lotes de empresa na rua de baixo de cada favela
const BASES_MORRO = [];           // { x, z, w, d, h, rampa }
export const CASAS_FAVELA = [];
const alicerces = [];             // [x, z, w, d, y, h]: base de concreto das casas no barranco
let malhaJanelas = null, matJanelas = null;
const janelasDe = new Map();      // índice do prédio -> [instâncias das janelas acesas]   // portas das casas (id 5000+, igual à tabela casas do banco: compra e aluguel)
let favelasProntas = false;
export function listaCasasFavela() { if (!favelasProntas) gerarFavelas(); return CASAS_FAVELA; }
function gerarFavelas() {
  if (favelasProntas) return; favelasProntas = true;
  const F = FAVELAS;
  // ---- Morro da Serra: rua principal subindo do centro de Vila Serra, três travessas e a laje da base no topo
  ruaMorro(0, -1107, 0, -1338);
  ruaMorro(-110, -1190, 110, -1190); ruaMorro(-110, -1260, 110, -1260); ruaMorro(-70, -1315, 70, -1315);
  ruaMorro(-90, -1190, -90, -1260); ruaMorro(90, -1190, 90, -1260);
  ruaMorro(86, -1107, 160, -1107); ruaMorro(-160, -1107, -86, -1107);   // rua dos lotes de empresa
  for (const x of [-137, -115, 115, 137]) LOTES_FAVELA.push({ x, z: -1124.5, portao: { x, z: -1111 } });
  limparArea(-165, -1392, 165, -1112);
  // ---- Morro do Porto: a rua z = 945 vem da rodovia, passa na Base Naval e chega ao pé do morro
  ruaMorro(86, 945, 216, 945, false); ruaMorro(216, 945, 760, 945, false); ruaMorro(760, 945, 1062, 945);
  ruaMorro(1050, 945, 1050, 1058); ruaMorro(960, 945, 960, 1045);
  ruaMorro(935, 1000, 1050, 1000); ruaMorro(935, 1045, 1050, 1045);
  for (const x of [915, 937, 959, 981]) LOTES_FAVELA.push({ x, z: 927.5, portao: { x, z: 941 } });
  limparArea(878, 910, 1100, 1112);
  // nada de árvore no asfalto das ruas dos morros (as pontas das ruas dos lotes saíam da área limpa)
  for (const [rx, rz, w, d] of ruasMorro) for (let k = arvores.length - 1; k >= 0; k--) {
    const [x, z, , c] = arvores[k]; if (Math.abs(x - rx) > w / 2 + 1.2 || Math.abs(z - rz) > d / 2 + 1.2) continue;
    if (c) Object.assign(c, { x: 1e7, z: 1e7, r: 0 }); arvores.splice(k, 1);
  }
  // ---- lajes das bases de clã (topo plano) e a rampa da rua até elas
  for (const [f, rampa] of [[F.serra, { x0: -5, x1: 5, de: -1320, ate: F.serra.base.z + F.serra.base.d / 2 }], [F.porto, { x0: 1045, x1: 1055, de: 1050, ate: F.porto.base.z - F.porto.base.d / 2 }]]) {
    const b = f.base, x0 = b.x - b.w / 2, x1 = b.x + b.w / 2, z0 = b.z - b.d / 2, z1 = b.z + b.d / 2;
    let h = 0, lo = Infinity;
    for (let x = x0; x <= x1; x += 2) for (let z = z0; z <= z1; z += 2) { const t = chaoNatural(x, z); h = Math.max(h, t); lo = Math.min(lo, t); }
    h += 0.3;
    pisos.push({ x0, x1, z0, z1, h });
    const z0r = Math.min(rampa.de, rampa.ate), z1r = Math.max(rampa.de, rampa.ate);
    pisos.push({ x0: rampa.x0, x1: rampa.x1, z0: z0r, z1: z1r, h, rampa: { eixo: 'z', de: rampa.de, ate: rampa.ate, h0: chaoNatural((rampa.x0 + rampa.x1) / 2, rampa.de), h1: h } });
    BASES_MORRO.push({ ...b, h, lo, rampa: { x0: rampa.x0, x1: rampa.x1, z0: z0r, z1: z1r }, f });
    // laje de concreto (a lateral vira muro de arrimo), mureta com a entrada da rampa, QG, caixa d'água e mastro
    extrasMesh.push({ geo: [b.w, h - lo + 2, b.d], cor: '#9a958b', pos: [b.x, (h + lo - 2) / 2, b.z] });
    const ent = Math.sign(rampa.de - rampa.ate);   // de que lado (z) chega a rampa
    const mur = (mx0, mz0, mx1, mz1) => { const w = Math.max(0.5, mx1 - mx0), d = Math.max(0.5, mz1 - mz0); extrasMesh.push({ geo: [w, 1.5, d], cor: '#c9c1b0', pos: [(mx0 + mx1) / 2, h + 0.75, (mz0 + mz1) / 2] }); addCol({ tipo: 'caixa', x0: mx0, x1: mx0 + w, z0: mz0, z1: mz0 + d }); };
    const zr = ent > 0 ? z1 - 0.5 : z0, zf = ent > 0 ? z0 : z1 - 0.5;
    mur(x0, zr, b.x - 6, zr + 0.5); mur(b.x + 6, zr, x1, zr + 0.5); mur(x0, zf, x1, zf + 0.5); mur(x0, z0, x0 + 0.5, z1); mur(x1 - 0.5, z0, x1, z1);
    const qz = b.z - ent * (b.d / 2 - 6);
    predio(b.x - 12, qz, 16, 8, 5.2, { y: h, cor: '#6d5a4a', loja: false, det: false });
    extrasMesh.push({ geo: [2.2, 1.6, 2.2], cor: '#2f6fd1', pos: [b.x - 16, h + 5.2 + 0.8, qz] });
    extrasMesh.push({ geo: [0.18, 10, 0.18], cor: '#d8d8d0', pos: [b.x + 14, h + 5, qz] });
    addCol({ tipo: 'circ', x: b.x + 14, z: qz, r: 0.3 });
  }
  // ---- casas: um bloco de 7 m por vez, com becos sobrando entre elas; nada em cima das ruas, da laje e dos lotes
  const livre = (x0, z0, x1, z1) => {
    for (const [rx, rz, w, d] of ruasMorro) if (x1 > rx - w / 2 - 1.2 && x0 < rx + w / 2 + 1.2 && z1 > rz - d / 2 - 1.2 && z0 < rz + d / 2 + 1.2) return false;
    for (const b of BASES_MORRO) {
      if (x1 > b.x - b.w / 2 - 3 && x0 < b.x + b.w / 2 + 3 && z1 > b.z - b.d / 2 - 3 && z0 < b.z + b.d / 2 + 3) return false;
      const r = b.rampa; if (x1 > r.x0 - 2 && x0 < r.x1 + 2 && z1 > r.z0 - 2 && z0 < r.z1 + 2) return false;
    }
    for (const l of LOTES_FAVELA) if (x1 > l.x - 11 && x0 < l.x + 11 && z1 > l.z - 11 && z0 < l.z + 14) return false;
    return true;
  };
  for (const f of Object.values(F)) {
    for (let cx = f.x0 + 4; cx < f.x1 - 3; cx += 7.2) for (let cz = f.z0 + 4; cz < f.z1 - 3; cz += 7.2) {
      if (rf() < 0.1) continue;   // beco / quintal
      const w = 4.2 + rf() * 2.6, d = 4.2 + rf() * 2.6, x = cx + (rf() - 0.5) * 1.4, z = cz + (rf() - 0.5) * 1.4;
      if (!livre(x - w / 2, z - d / 2, x + w / 2, z + d / 2)) continue;
      const hs = [[-1, -1], [1, -1], [-1, 1], [1, 1], [0, 0]].map(([a, b]) => chaoNatural(x + a * w / 2, z + b * d / 2));
      const lo = Math.min(...hs), hi = Math.max(...hs), andares = 1 + Math.floor(rf() * rf() * 3.6);
      const topo = hi + 0.15;   // a casa começa no nível do ponto mais alto do terreno; embaixo, o alicerce de concreto
      const i = predio(x, z, w, d, andares * 2.9, { y: topo, cor: CORES_FAVELA[Math.floor(rf() * CORES_FAVELA.length)], loja: false, det: false });
      alicerces.push([x, z, w + 0.12, d + 0.12, lo - 0.6, topo - lo + 0.6]);
      // frente virada para a rua mais perto (o modelo 3D olha para +z)
      let rumo = 0, dm = Infinity;
      for (const [rx, rz, rw, rd, vert] of ruasMorro) {
        const dx = Math.max(0, Math.abs(x - rx) - rw / 2), dz = Math.max(0, Math.abs(z - rz) - rd / 2), dd = Math.hypot(dx, dz);
        if (dd < dm) { dm = dd; rumo = vert ? (rx > x ? Math.PI / 2 : -Math.PI / 2) : (rz > z ? 0 : Math.PI); }
      }
      Object.assign(edificios[i], { tipo: 'favela', k: 1 + Math.floor(rf() * 4), rumo, andares });
      { const meia = Math.abs(Math.sin(rumo)) > 0.5 ? w / 2 : d / 2, px = x + Math.sin(rumo) * (meia + 0.8), pz = z + Math.cos(rumo) * (meia + 0.8);
        const fav = f === F.serra ? 'serra' : 'porto', nfav = CASAS_FAVELA.filter((q) => q.favela === fav).length + 1;
        CASAS_FAVELA.push({ id: 5000 + CASAS_FAVELA.length, x: Math.round(px * 10) / 10, z: Math.round(pz * 10) / 10, favela: fav, rotulo: `${fav === 'serra' ? 'Morro da Serra' : 'Morro do Porto'} · casa ${nfav}` }); }
      if (rf() < 0.45) { edificios[i].det.push(detalhes.length); detalhes.push({ ed: i, dx: (rf() - 0.5) * (w - 1.6), dz: (rf() - 0.5) * (d - 1.6), w: 1.2, h: 1, d: 1.2 }); }   // caixa d'água
    }
    extras.push({ x0: f.x0, x1: f.x1, z0: f.z0, z1: f.z1, cor: '#a88a68' });
  }
}
// terreno do Morro do Porto, ruas acompanhando o relevo e o paredão de pedra sobre o mar
function montarFavelasMalhas() {
  // alicerces: concreto liso, com um tom levemente diferente em cada casa
  if (alicerces.length) {
    const im = new THREE.InstancedMesh(new THREE.BoxGeometry(1, 1, 1).translate(0, 0.5, 0), new THREE.MeshStandardMaterial({ color: '#ffffff', roughness: 0.95 }), alicerces.length);
    alicerces.forEach(([x, z, w, d, y, h], k) => { _m.compose(_v.set(x, y, z), _q.identity(), _e.set(w, h, d)); im.setMatrixAt(k, _m); im.setColorAt(k, _c.set(['#8f8a80', '#9a958b', '#85817a', '#a39e93'][k % 4])); });
    im.castShadow = true; im.receiveShadow = true; ctx.scene.add(im);
  }
  // janelas acesas à noite nas casas da favela (quadros de luz na frente da casa; acendem com a noite)
  const lista = [];
  edificios.forEach((e, i) => {
    if (e.tipo !== 'favela') return;
    const lado = Math.abs(Math.sin(e.rumo)) > 0.5, larg = lado ? e.d : e.w, meia = (lado ? e.w : e.d) / 2 + 0.04;
    const fx = Math.sin(e.rumo), fz = Math.cos(e.rumo), rx = Math.cos(e.rumo), rz = -Math.sin(e.rumo);
    const porAndar = larg > 5.4 ? 2 : 1, idx = [];
    for (let a = 0; a < (e.andares || 1); a++) for (let k = 0; k < porAndar; k++) {
      const h = Math.abs(Math.sin(i * 12.9898 + a * 78.233 + k * 37.719) * 43758.5453) % 1;   // sorteio fixo (não mexe no resto)
      if (h > 0.68) continue;   // nem toda janela fica acesa
      const off = porAndar === 1 ? (a % 2 ? 0.9 : -0.9) : (k ? 1 : -1) * larg * 0.24;
      idx.push(lista.length);
      lista.push([e.x + fx * meia + rx * off, e.y + 1.35 + a * 2.9, e.z + fz * meia + rz * off, e.rumo]);
    }
    if (idx.length) janelasDe.set(i, idx);
  });
  if (lista.length) {
    matJanelas = new THREE.MeshBasicMaterial({ color: '#ffd58a', transparent: true, opacity: 0, depthWrite: false, toneMapped: false });
    malhaJanelas = new THREE.InstancedMesh(new THREE.PlaneGeometry(0.85, 0.85), matJanelas, lista.length);
    lista.forEach(([x, y, z, r], k) => { _q.setFromAxisAngle(_v.set(0, 1, 0), r); _m.compose(_v.set(x, y, z), _q, _e.set(1, 1, 1)); malhaJanelas.setMatrixAt(k, _m); });
    malhaJanelas.visible = false; malhaJanelas.frustumCulled = false; ctx.scene.add(malhaJanelas);
  }
  const geo = new THREE.PlaneGeometry(200, 164, 80, 66).rotateX(-Math.PI / 2), pp = geo.attributes.position;
  for (let k = 0; k < pp.count; k++) { const x = pp.getX(k) + 1000, z = pp.getZ(k) + 1030; pp.setY(k, morroPorto(x, z) + 0.05); }
  geo.computeVertexNormals();
  const terreno = new THREE.Mesh(geo, MAT.campo); terreno.position.set(1000, 0, 1030); terreno.receiveShadow = true; ctx.scene.add(terreno);
  const rocha = new THREE.MeshStandardMaterial({ color: '#7a7266', roughness: 1, flatShading: true });
  for (let x = 900; x < 1100; x += 10) { const h = Math.max(morroPorto(x + 5, 1107), 0.6) + 0.4; const m = new THREE.Mesh(new THREE.BoxGeometry(10.4, h + 3, 4), rocha); m.position.set(x + 5, (h - 3) / 2, 1110); m.castShadow = true; ctx.scene.add(m); }
  for (let z = 950; z < 1112; z += 10) { const h = Math.max(morroPorto(1095, z + 5), 0.6) + 0.4; const m = new THREE.Mesh(new THREE.BoxGeometry(4, h + 3, 10.4), rocha); m.position.set(1098, (h - 3) / 2, z + 5); m.castShadow = true; ctx.scene.add(m); }
  for (const [x, z, w, d, vert, desenhar] of ruasMorro) {
    if (!desenhar) continue;
    const nx = Math.max(1, Math.round(w / (vert ? 5 : 2.5))), nz = Math.max(1, Math.round(d / (vert ? 2.5 : 5)));
    const g = new THREE.PlaneGeometry(w, d, nx, nz).rotateX(-Math.PI / 2), q = g.attributes.position;
    for (let k = 0; k < q.count; k++) { const vx = q.getX(k) + x, vz = q.getZ(k) + z; q.setY(k, (alturaBase(vx, vz, false) ?? 0) + 0.1); }
    g.computeVertexNormals();
    const m = new THREE.Mesh(g, MAT.asfalto); m.position.set(x, 0, z); m.receiveShadow = true; ctx.scene.add(m);
  }
}
const arbustos = [];
function montarQuartel() {
  const Q = QUARTEL, cx = (Q.x0 + Q.x1) / 2, cz = (Q.z0 + Q.z1) / 2, pz = Q.portao.z;
  rua((86 + Q.x0) / 2, pz, Q.x0 - 86, RW);                                    // estrada da cidade até o portão
  calcadas.push([cx, cz, Q.x1 - Q.x0, Q.z1 - Q.z0, 0.12]);                   // chão do quartel
  pisos.push({ x0: Q.x0, x1: Q.x1, z0: Q.z0, z1: Q.z1, h: 0.12 });
  extras.push({ x0: Q.x0, x1: Q.x1, z0: Q.z0, z1: Q.z1, cor: '#7d8a5c' });
  // muro com portão no lado oeste
  const muro = (x0, z0, x1, z1) => {
    const w = Math.max(0.6, x1 - x0), d = Math.max(0.6, z1 - z0);
    extrasMesh.push({ geo: [w, 3, d], cor: '#8c8a6e', pos: [(x0 + x1) / 2, 1.5, (z0 + z1) / 2] });
    addCol({ tipo: 'caixa', x0, x1: x0 + w, z0, z1: z0 + d });
  };
  muro(Q.x0, Q.z0, Q.x1, Q.z0 + 0.6); muro(Q.x0, Q.z1 - 0.6, Q.x1, Q.z1); muro(Q.x1 - 0.6, Q.z0, Q.x1, PASSAGEM_BASES.z0); muro(Q.x1 - 0.6, PASSAGEM_BASES.z1, Q.x1, Q.z1);   // passagem para a Base Aérea
  muro(Q.x0, Q.z0, Q.x0 + 0.6, pz - 6); muro(Q.x0, pz + 6, Q.x0 + 0.6, Q.z1);
  // guarita e cancela no portão
  extrasMesh.push({ geo: [3, 3.2, 3], cor: '#5e6b45', pos: [Q.x0 + 2, 1.6, pz - 8.5] });
  extrasMesh.push({ geo: [3.4, 0.25, 3.4], cor: '#3b4430', pos: [Q.x0 + 2, 3.3, pz - 8.5] });
  addCol({ tipo: 'caixa', x0: Q.x0 + 0.5, x1: Q.x0 + 3.5, z0: pz - 10, z1: pz - 7 });
  // torres de vigia nos cantos
  for (const [x, z] of [[Q.x0 + 2, Q.z0 + 2], [Q.x1 - 2, Q.z0 + 2], [Q.x0 + 2, Q.z1 - 2], [Q.x1 - 2, Q.z1 - 2]]) {
    extrasMesh.push({ geo: [0.5, 8, 0.5], cor: '#4a5238', pos: [x, 4, z] });
    extrasMesh.push({ geo: [3.4, 2.2, 3.4], cor: '#5e6b45', pos: [x, 9.1, z] });
    extrasMesh.push({ geo: [4, 0.3, 4], cor: '#3b4430', pos: [x, 10.35, z] });
  }
  // prédios fechados: alojamento e paiol (o comando, com interior, e a garagem aberta ficam no civico.js)
  predio(cx + 26, Q.z1 - 15, 34, 16, 7, { y: 0.12, cor: '#9aa070', loja: false });          // alojamento
  predio(Q.x0 + 13, Q.z0 + 11, 16, 12, 5, { y: 0.12, cor: '#8f9470', loja: false, det: false });     // paiol
  // pátio de formatura e mastro
  calcadas.push([Q.patio.x, Q.patio.z, 40, 34, 0.14]);
  extrasMesh.push({ geo: [0.25, 12, 0.25], cor: '#d8d8d0', pos: [Q.patio.x + 22, 6, Q.patio.z] });
  extrasMesh.push({ geo: [0.06, 1.6, 2.6], cor: '#2f7d3a', pos: [Q.patio.x + 22, 11, Q.patio.z + 1.35] });
  extrasMesh.push({ geo: [0.07, 0.9, 1.4], cor: '#e2c234', pos: [Q.patio.x + 22, 11, Q.patio.z + 1.35] });
  addCol({ tipo: 'circ', x: Q.patio.x + 22, z: Q.patio.z, r: 0.3 });
  for (const sz of [-1, 1]) for (let k = 0; k < 5; k++) arvore(Q.x0 + 6 + k * 9, pz + sz * 14, 0.8);
}

// ---------------------------------------------------------------- malhas
const _m = new THREE.Matrix4(), _q = new THREE.Quaternion(), _v = new THREE.Vector3(), _e = new THREE.Vector3(), _c = new THREE.Color();
let malhaPredios = null, malhaTelhas = null, malhaDet = null;
const idxTelha = new Map();

function geoTelhado() {
  // prisma de 1 x 1 x 1: cumeeira ao longo de X, base em y = 0
  const p = [
    -0.5, 0, 0.5, 0.5, 0, 0.5, 0.5, 1, 0, -0.5, 0, 0.5, 0.5, 1, 0, -0.5, 1, 0,
    0.5, 0, -0.5, -0.5, 0, -0.5, -0.5, 1, 0, 0.5, 0, -0.5, -0.5, 1, 0, 0.5, 1, 0,
    0.5, 0, 0.5, 0.5, 0, -0.5, 0.5, 1, 0, -0.5, 0, -0.5, -0.5, 0, 0.5, -0.5, 1, 0,
  ];
  const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.Float32BufferAttribute(p, 3)); g.computeVertexNormals(); return g;
}
function matrizPredio(e, h = e.h) { _m.compose(_v.set(e.x, e.y, e.z), _q.identity(), _e.set(e.w, Math.max(0.01, h), e.d)); return _m; }
function matrizTelha(e, visivel = true) {
  _q.setFromAxisAngle(_e.set(0, 1, 0), e.rot);
  const [a, b] = e.rot ? [e.d + 0.7, e.w + 0.7] : [e.w + 0.7, e.d + 0.7];
  if (!visivel) return _m.makeScale(0, 0, 0);   // escondido de verdade: achatado (0,01) ele virava uma placa voando em cima do prédio 3D
  _m.compose(_v.set(e.x, e.y + e.h, e.z), _q, _e.set(a, 2.6, b)); return _m;
}
function matrizDet(dt, visivel = true) {
  const e = edificios[dt.ed];
  if (!visivel) return _m.makeScale(0, 0, 0);
  _m.compose(_v.set(e.x + dt.dx, e.y + e.h, e.z + dt.dz), _q.identity(), _e.set(dt.w, dt.h, dt.d)); return _m;
}

function montarMalhas() {
  const { scene } = ctx;
  for (const e of extrasMesh) {
    const m = new THREE.Mesh(new THREE.BoxGeometry(...e.geo), e.vidro ? new THREE.MeshStandardMaterial({ color: e.cor, roughness: 0.1, metalness: 0.4 }) : new THREE.MeshStandardMaterial({ color: e.cor, roughness: 0.6 }));
    m.position.set(...e.pos); m.castShadow = true; scene.add(m);
  }
  const caixaBase = new THREE.BoxGeometry(1, 1, 1).translate(0, 0.5, 0);
  const geoPredio = caixaBase.clone();
  geoPredio.setAttribute('aLoja', new THREE.InstancedBufferAttribute(new Float32Array(edificios.map((e) => (e.tipo === 'predio' && e.loja !== false ? 1 : 0))), 1));
  malhaPredios = new THREE.InstancedMesh(geoPredio, MAT.fachada, edificios.length);
  edificios.forEach((e, i) => { malhaPredios.setMatrixAt(i, matrizPredio(e)); malhaPredios.setColorAt(i, _c.set(e.cor)); });
  malhaPredios.castShadow = true; malhaPredios.receiveShadow = true; scene.add(malhaPredios);

  const casas = edificios.map((e, i) => [e, i]).filter(([e]) => e.tipo === 'casa');
  malhaTelhas = new THREE.InstancedMesh(geoTelhado(), MAT.telha, Math.max(1, casas.length));
  casas.forEach(([e, i], k) => { idxTelha.set(i, k); malhaTelhas.setMatrixAt(k, matrizTelha(e)); malhaTelhas.setColorAt(k, _c.set(e.telha)); });
  malhaTelhas.castShadow = true; malhaTelhas.receiveShadow = true; scene.add(malhaTelhas);

  malhaDet = new THREE.InstancedMesh(caixaBase, MAT.detalhe, Math.max(1, detalhes.length));
  detalhes.forEach((d, k) => malhaDet.setMatrixAt(k, matrizDet(d)));
  malhaDet.castShadow = true; scene.add(malhaDet);

  // calçadas
  const calc = new THREE.InstancedMesh(new THREE.BoxGeometry(1, 1, 1), MAT.calcada, calcadas.length);
  calcadas.forEach(([x, z, w, d, y], k) => { _m.compose(_v.set(x, y / 2, z), _q.identity(), _e.set(w, y, d)); calc.setMatrixAt(k, _m); });
  calc.receiveShadow = true; scene.add(calc);
  // gramados
  const planoChao = new THREE.PlaneGeometry(1, 1).rotateX(-Math.PI / 2);
  const gram = new THREE.InstancedMesh(planoChao, MAT.grama, Math.max(1, gramados.length));
  gramados.forEach(([x, z, w, d], k) => { _m.compose(_v.set(x, 0.185, z), _q.identity(), _e.set(w, 1, d)); gram.setMatrixAt(k, _m); });
  gram.receiveShadow = true; scene.add(gram);
  // ruas
  for (const vert of [false, true]) {
    const lista = ruas.filter((r) => r[4] === vert);
    const im = new THREE.InstancedMesh(planoChao, MAT.asfalto, lista.length);
    lista.forEach(([x, z, w, d], k) => { _m.compose(_v.set(x, vert ? 0.022 : 0.012, z), _q.identity(), _e.set(w, 1, d)); im.setMatrixAt(k, _m); });
    im.receiveShadow = true; scene.add(im);
  }
  // árvores
  const pinheiro = (x, z) => ((Math.abs(x * 7.3 + z * 3.1) | 0) % 5) === 0;
  const folhosas = arvores.filter(([x, z]) => !pinheiro(x, z)), pinheiros = arvores.filter(([x, z]) => pinheiro(x, z));
  const tronco = new THREE.InstancedMesh(new THREE.CylinderGeometry(0.13, 0.24, 2.0, 7).translate(0, 1.0, 0), MAT.tronco, arvores.length);
  const copa = new THREE.InstancedMesh(geoCopa([[0, 0, 0, 1.25], [0.75, -0.25, 0.3, 0.9], [-0.7, -0.15, -0.35, 0.95], [0.2, 0.55, -0.45, 0.85], [-0.25, -0.35, 0.7, 0.8]]), MAT.copa, Math.max(1, folhosas.length));
  const pinho = new THREE.InstancedMesh(geoPinheiro(), MAT.copa, Math.max(1, pinheiros.length));
  copa.count = folhosas.length; pinho.count = pinheiros.length;
  const verdes = ['#5a8a3c', '#679a42', '#4b7d36', '#78a34a', '#5f8a3a', '#6e9a3e'];
  const escuros = ['#3f6b38', '#355f33', '#47753c'];
  let kf = 0, kp = 0;
  const info = [];
  arvores.forEach(([x, z, s], k) => {
    const y = altura(x, z) ?? 0, var1 = 0.88 + ((x * 31 + z * 17) % 1 + 1) % 1 * 0.3, sc = s * var1;
    const giro = (x * 13 + z * 7) % 6.28;
    _q.setFromAxisAngle(_e.set(0, 1, 0), giro);
    if (pinheiro(x, z)) {
      _m.compose(_v.set(x, y, z), _q, _e.set(sc * 0.8, sc * 0.7, sc * 0.8)); tronco.setMatrixAt(k, _m);
      _m.compose(_v.set(x, y + 0.6 * sc, z), _q, _e.set(sc, sc * 1.1, sc)); pinho.setMatrixAt(kp, _m);
      info.push({ x, z, y, sc, giro, tipo: 1, idx: kp, perto: false });
      pinho.setColorAt(kp++, _c.set(escuros[k % escuros.length]));
    } else {
      _m.compose(_v.set(x, y, z), _q, _e.set(sc, sc, sc)); tronco.setMatrixAt(k, _m);
      _m.compose(_v.set(x, y + 2.55 * sc, z), _q, _e.set(sc * 1.05, sc * 1.0, sc * 1.05)); copa.setMatrixAt(kf, _m);
      info.push({ x, z, y, sc, giro, tipo: z > 880 && Math.abs(x * 7) % 2 > 1 ? 2 : 0, idx: kf, perto: false });   // Porto Sul: metade vira palmeira
      copa.setColorAt(kf++, _c.set(verdes[k % verdes.length]));
    }
  });
  pinho.castShadow = true; pinho.receiveShadow = true; if (pinheiros.length) scene.add(pinho);
  tronco.castShadow = true; copa.castShadow = true; copa.receiveShadow = true; scene.add(tronco); if (folhosas.length) scene.add(copa);
  // árvores 3D (GLB) perto do jogador; as de longe continuam leves
  const MAXA = window.matchMedia?.('(pointer: coarse)').matches ? 70 : 150, MAXA_ULTRA = 220;   // capacidade do ultra (o normal usa só MAXA)
  // modelos novos (prop_arvore / prop_pinheiro, altura 1 centrada) quando existem; senão os antigos
  const ESC = [0.68, 0.6, 0.78], ALVO = [4.4, 4.8];
  // árvore comum: o carvalho do Meshy (simplificado) quando existe; senão os modelos antigos
  const glbA = [['arvore_carvalho', 'prop_arvore', 'arvore_comum'], ['prop_pinheiro', 'arvore_pinheiro'], ['arvore_palmeira']].map((nomes, k) => {
    const n = nomes.find((x) => ctx.modelo?.(x)); if (!n) return null;
    const base = ctx.modelo(n); let malha = null;
    base.updateMatrixWorld(true); base.traverse((o) => { if (o.isMesh && !malha) malha = o; }); if (!malha) return null;
    const geo = malha.geometry.clone().applyMatrix4(new THREE.Matrix4().copy(base.matrixWorld).invert().multiply(malha.matrixWorld));
    const carvalho = n === 'arvore_carvalho';
    if (n.startsWith('prop_') || carvalho) { geo.computeBoundingBox(); const bb = geo.boundingBox; geo.translate(-(bb.min.x + bb.max.x) / 2, -bb.min.y, -(bb.min.z + bb.max.z) / 2); ESC[k] = (carvalho ? 5.6 : ALVO[k]) / ((bb.max.y - bb.min.y) || 1); }
    const orig = [].concat(malha.material)[0];
    const m = carvalho ? new THREE.MeshStandardMaterial({ map: orig.map, normalMap: orig.normalMap, roughness: 0.9, metalness: 0 }) : orig.clone();
    if (!carvalho) { m.vertexColors = true; m.flatShading = true; m.roughness = 0.9; }
    const im = new THREE.InstancedMesh(geo, m, MAXA_ULTRA); im.count = 0; im.castShadow = true; im.receiveShadow = true; im.frustumCulled = false; scene.add(im);
    return im;
  });
  arvoresLod = { info, tronco, copa, pinho, glb: glbA, max: MAXA, maxUltra: MAXA_ULTRA, t: 0, ESC };
  // arbustos da mata (sem colisão)
  if (arbustos.length) {
    const ab = new THREE.InstancedMesh(geoCopa([[0, 0.45, 0, 0.7], [0.55, 0.3, 0.2, 0.5], [-0.5, 0.3, -0.2, 0.55]]), MAT.copa, arbustos.length);
    arbustos.forEach(([x, z, e], k) => { _m.compose(_v.set(x, altura(x, z) ?? 0, z), _q.setFromAxisAngle(_e.set(0, 1, 0), x * 3.1), _e.set(e, e * 0.8, e)); ab.setMatrixAt(k, _m); ab.setColorAt(k, _c.set(['#4f7d36', '#5b8a3c', '#466f33'][k % 3])); });
    ab.receiveShadow = true; scene.add(ab);
  }
}

function plano(x, z, w, d, y, mat) {
  const m = new THREE.Mesh(new THREE.PlaneGeometry(w, d).rotateX(-Math.PI / 2), mat);
  m.position.set(x, y, z); m.receiveShadow = true; ctx.scene.add(m); return m;
}

function montarChaos() {
  // chão escuro sob o horizonte de prédios
  const H = FIM_HORIZONTE + 2;
  for (const s of [-1, 1]) {
    for (const [a, b] of [[-H, -CORREDOR], [CORREDOR, H]]) plano((a + b) / 2, s * (BORDA + H) / 2, b - a, H - BORDA, 0.006, MAT.chaoHorizonte);
    plano(s * (BORDA + H) / 2, 0, H - BORDA, BORDA * 2, 0.006, MAT.chaoHorizonte);
  }
  // faixa verde da ferrovia dentro da metrópole e campos até as cidades
  for (const s of [-1, 1]) {
    plano(0, s * (METADE + H) / 2, CORREDOR * 2, H - METADE, 0.008, MAT.grama);
    plano(0, s * (H + 1300) / 2, 2000, 1300 - H, 0.004, MAT.campo);
  }
  // muro baixo no limite da metrópole, cortado pelos trilhos
  const cerca = new THREE.MeshStandardMaterial({ color: '#4c5a48', roughness: 0.8 });
  for (const s of [-1, 1]) for (const [a, b] of [[-CORREDOR, -10], [10, CORREDOR]]) {
    const m = new THREE.Mesh(new THREE.BoxGeometry(b - a, 1.4, 0.3), cerca); m.position.set((a + b) / 2, 0.7, s * (BORDA - 2)); m.castShadow = true; ctx.scene.add(m);
  }
  // o morro da Serra (dá para subir) e, bem longe, a serra de fundo
  const W = 900, D = 380, geo = new THREE.PlaneGeometry(W, D, 90, 38).rotateX(-Math.PI / 2);
  const pp = geo.attributes.position;
  for (let k = 0; k < pp.count; k++) { const x = pp.getX(k), z = pp.getZ(k) - 1340; pp.setY(k, morro(x, z) + 0.05); }
  geo.computeVertexNormals();
  const terreno = new THREE.Mesh(geo, MAT.campo); terreno.position.z = -1340; terreno.receiveShadow = true; ctx.scene.add(terreno);
  const cone = new THREE.ConeGeometry(1, 1, 7).translate(0, 0.5, 0);
  const morros = [];
  for (let k = 0; k < 22; k++) morros.push([entre(-900, 900), -entre(2050, 2350), entre(90, 180), entre(70, 140)]);   // serra de fundo: ilhas ao norte, longe da rota dos navios
  const im = new THREE.InstancedMesh(cone, MAT.morro, morros.length);
  morros.forEach(([x, z, r, h], k) => { _m.compose(_v.set(x, 0, z), _q.identity(), _e.set(r, h, r)); im.setMatrixAt(k, _m); im.setColorAt(k, _c.set(escolher(['#7d8f63', '#6f8259', '#8a9a6c', '#76866a']))); });
  im.receiveShadow = true; ctx.scene.add(im);
  montarFavelasMalhas();
  // chão por baixo de tudo, até a costa, e o mar em volta da ilha inteira (os navios dão a volta)
  plano((ILHA.x0 + ILHA.x1) / 2, (ILHA.z0 + ILHA.z1) / 2, ILHA.x1 - ILHA.x0, ILHA.z1 - ILHA.z0, -0.03, MAT.campo);
  const M = 2800;
  plano(0, (ILHA.z1 + M) / 2, 2 * M, M - ILHA.z1, 0.03, MAT.agua);                                    // sul (Porto Sul)
  plano(0, (ILHA.z0 - M) / 2, 2 * M, M + ILHA.z0, 0.03, MAT.agua);                                    // norte
  plano((ILHA.x0 - M) / 2, (ILHA.z0 + ILHA.z1) / 2, M + ILHA.x0, ILHA.z1 - ILHA.z0, 0.03, MAT.agua);   // oeste
  plano((ILHA.x1 + M) / 2, (ILHA.z0 + ILHA.z1) / 2, M - ILHA.x1, ILHA.z1 - ILHA.z0, 0.03, MAT.agua);   // leste
  extras.push({ x0: -M, x1: M, z0: ILHA.z1, z1: M, cor: '#3e7ea6' }, { x0: -M, x1: M, z0: -M, z1: ILHA.z0, cor: '#3e7ea6' },
    { x0: -M, x1: ILHA.x0, z0: ILHA.z0, z1: ILHA.z1, cor: '#3e7ea6' }, { x0: ILHA.x1, x1: M, z0: ILHA.z0, z1: ILHA.z1, cor: '#3e7ea6' });
  // o mar de Porto Sul, cais, píer e um navio
  const cais = new THREE.Mesh(new THREE.BoxGeometry(200, 0.8, 1.2), MAT.concreto); cais.position.set(0, 0.2, 1113); ctx.scene.add(cais);
  const pier = new THREE.Mesh(new THREE.BoxGeometry(10, 0.5, 70), MAT.concreto); pier.position.set(48, 0.25, 1148); pier.receiveShadow = true; ctx.scene.add(pier);
  const navio = ctx.modelo?.('navio');
  if (navio) {   // cargueiro em 3D: convés a 4 m (o casco fica 1,1 m dentro d'água)
    const n = navio.clone(); n.position.set(66, -1.1, 1160); n.traverse((o) => { if (o.isMesh) { o.castShadow = true; o.receiveShadow = true; } }); ctx.scene.add(n);
    return;
  }
  const casco = new THREE.Mesh(new THREE.BoxGeometry(14, 5, 62), new THREE.MeshStandardMaterial({ color: '#7d2a24', roughness: 0.6 })); casco.position.set(66, 1.5, 1160); casco.castShadow = true; ctx.scene.add(casco);
  const ponte = new THREE.Mesh(new THREE.BoxGeometry(11, 6, 10), new THREE.MeshStandardMaterial({ color: '#efefea', roughness: 0.5 })); ponte.position.set(66, 7, 1182); ponte.castShadow = true; ctx.scene.add(ponte);
  const conts = ['#c43b3b', '#3b6fd2', '#2f9e5b', '#c98a1c', '#8a3bc4', '#3b9ec4'];
  for (let k = 0; k < 14; k++) {
    const c = new THREE.Mesh(new THREE.BoxGeometry(2.6, 2.6, 6), new THREE.MeshStandardMaterial({ color: conts[k % conts.length], roughness: 0.7 }));
    c.position.set(66 + (k % 3 - 1) * 3.2, 5.3 + Math.floor(k / 9) * 2.6, 1140 + Math.floor((k % 9) / 3) * 7); c.castShadow = true; ctx.scene.add(c);
  }
}

// ---------------------------------------------------------------- terreno de obra pública: tira os prédios do quarteirão
// (depois de gerar o mapa, sem mexer no sorteio: o resto da cidade fica igual). A calçada continua.
const quadrasLivres = new Set();
export function liberarQuadra(cx, cz) {
  const k = cx + ',' + cz; if (quadrasLivres.has(k) || !malhaPredios) return; quadrasLivres.add(k);
  const x0 = cx - QB / 2, x1 = cx + QB / 2, z0 = cz - QB / 2, z1 = cz + QB / 2;
  const dentro = (x, z) => x > x0 && x < x1 && z > z0 && z < z1;
  edificios.forEach((e, i) => {
    if (!dentro(e.x, e.z) || e.removido) return;
    e.removido = true; e.h = 0.001; em3d.delete(i); cortados.delete(i);
    malhaPredios.setMatrixAt(i, _m.makeScale(0, 0, 0));
    if (idxTelha.has(i)) malhaTelhas.setMatrixAt(idxTelha.get(i), _m.makeScale(0, 0, 0));
    for (const d of e.det) malhaDet.setMatrixAt(d, _m.makeScale(0, 0, 0));
    e.det = [];
  });
  for (const l of grade.values()) for (const c of l) {
    if (c.tipo === 'caixa' && c.x0 >= x0 - 0.01 && c.x1 <= x1 + 0.01 && c.z0 >= z0 - 0.01 && c.z1 <= z1 + 0.01) Object.assign(c, { x0: 1e7, x1: 1e7, z0: 1e7, z1: 1e7 });
  }
  malhaPredios.instanceMatrix.needsUpdate = true; malhaTelhas.instanceMatrix.needsUpdate = true; malhaDet.instanceMatrix.needsUpdate = true;
  refazer3d = true;
}

// ---------------------------------------------------------------- prédios que tapam o jogador ficam cortados
const cortados = new Set();
const _ray = new THREE.Ray(), _box = new THREE.Box3();
let tempoOclusao = 0;
function definirCorte(i, cortar) {
  const e = edificios[i];
  if (e.removido) return;
  if (cortar && em3d.has(i)) { em3d.delete(i); refazer3d = true; }
  malhaPredios.setMatrixAt(i, matrizPredio(e, cortar ? Math.min(e.h, 2.2) : e.h));
  if (idxTelha.has(i)) malhaTelhas.setMatrixAt(idxTelha.get(i), matrizTelha(e, !cortar));
  for (const k of e.det) malhaDet.setMatrixAt(k, matrizDet(detalhes[k], !cortar));
}
export function atualizarOclusao(dt, pos, dirCamera) {
  tempoOclusao -= dt; if (tempoOclusao > 0 || !malhaPredios) return;
  tempoOclusao = 0.15;
  _ray.origin.set(pos.x, pos.y + 1.1, pos.z); _ray.direction.copy(dirCamera);
  const agora = new Set();
  if (pos.x < 1500) {
    const vistos = new Set();
    for (const k of chaves(pos.x - 130, pos.z - 130, pos.x + 130, pos.z + 130)) {
      for (const i of gradeEd.get(k) || []) {
        if (vistos.has(i)) continue; vistos.add(i);
        const e = edificios[i];
        if (pos.y > e.y + e.h - 1.5 && Math.abs(pos.x - e.x) < e.w / 2 + 3 && Math.abs(pos.z - e.z) < e.d / 2 + 3) continue;   // em cima do telhado (helicóptero/pássaro): o prédio fica inteiro
        _box.min.set(e.x - e.w / 2, e.y, e.z - e.d / 2); _box.max.set(e.x + e.w / 2, e.y + e.h + (e.tipo === 'casa' ? 2.6 : 2.2), e.z + e.d / 2);
        if (_ray.intersectsBox(_box)) agora.add(i);
      }
    }
  }
  let mudou = false;
  for (const i of cortados) if (!agora.has(i)) { definirCorte(i, false); cortados.delete(i); mudou = true; }
  for (const i of agora) if (!cortados.has(i)) { definirCorte(i, true); cortados.add(i); mudou = true; }
  if (mudou) { malhaPredios.instanceMatrix.needsUpdate = true; malhaTelhas.instanceMatrix.needsUpdate = true; malhaDet.instanceMatrix.needsUpdate = true; }
  if (refazer3d) { tempo3d = 0; refazer3d = false; }
}

// ---------------------------------------------------------------- prédios 3D (GLB) perto do jogador
// Os prédios e casas mais perto trocam a caixa pelo modelo 3D do tipo (casa, sobrado, residencial, escritório, galpão),
// esticado para o tamanho do lote e virado para a rua. Os de longe continuam caixas leves. Quantos e até onde depende da
// qualidade gráfica (Baixa = nenhum). Prédio cortado (tapando o jogador na câmera de cima) volta a ser caixa cortada.
const em3d = new Map();   // índice do prédio -> tipo do modelo
let refazer3d = false, tempo3d = 0, modelos3d = null;
export function ativarPredios3d(mapa) {   // mapa: nome -> cena do GLB
  modelos3d = {};
  for (const [nome, cena] of Object.entries(mapa)) {
    let malha = null; cena.updateMatrixWorld(true); cena.traverse((o) => { if (o.isMesh && !malha) malha = o; }); if (!malha) continue;
    const geo = malha.geometry.clone();
    for (const k of Object.keys(geo.attributes)) {   // posição quantizada (inteiros) vira float antes de transformar
      const a = geo.attributes[k]; if (a.array instanceof Float32Array) continue;
      const f = new Float32Array(a.count * a.itemSize), get = ['getX', 'getY', 'getZ', 'getW']; for (let i = 0; i < a.count; i++) for (let c = 0; c < a.itemSize; c++) f[i * a.itemSize + c] = a[get[c]](i);
      geo.setAttribute(k, new THREE.BufferAttribute(f, a.itemSize));
    }
    geo.applyMatrix4(new THREE.Matrix4().copy(cena.matrixWorld).invert().multiply(malha.matrixWorld));
    // normaliza: base no chão (y = 0), centrado e com tamanho 1 × 1 × 1, para ocupar exatamente o lugar da caixa do prédio
    // (os modelos vêm centrados na altura: sem isso, metade ficava enterrada)
    geo.computeBoundingBox();
    { const bb = geo.boundingBox, sx = (bb.max.x - bb.min.x) || 1, sy = (bb.max.y - bb.min.y) || 1, sz = (bb.max.z - bb.min.z) || 1;
      geo.translate(-(bb.min.x + bb.max.x) / 2, -bb.min.y, -(bb.min.z + bb.max.z) / 2); geo.scale(1 / sx, 1 / sy, 1 / sz); }
    geo.computeBoundingBox(); if (!geo.attributes.normal) geo.computeVertexNormals();
    const mat = [].concat(malha.material)[0];
    const im = new THREE.InstancedMesh(geo, mat, 48); im.count = 0; im.castShadow = true; im.receiveShadow = true; im.frustumCulled = false; ctx.scene.add(im);
    modelos3d[nome] = im;
  }
  tempo3d = 0;
}
// que modelo usar e para onde o prédio olha (a rua mais perto do lote)
function tipo3d(e) {
  if (e.removido) return null;
  if (e.y === 0) return null;                                        // horizonte: longe demais, fica caixa
  if (e.tipo === 'favela') return `favela_casa${e.k || 1}`;          // só troca se o GLB existir
  if (e.tipo === 'casa') return e.h > 4 ? 'predio_sobrado' : (Math.round(e.x * 7 + e.z * 3) % 2 ? 'predio_casa1' : 'predio_casa2');
  if (e.loja === false && e.w > 30) return 'predio_galpao';
  if (e.w >= 28 && e.d >= 22 && e.h >= 30 && e.loja === false) return null;   // prédio de apartamentos especial (tem portaria própria)
  return e.h <= 15 ? 'predio_residencial' : 'predio_escritorio';
}
function rumo3d(e) {
  if (e.rumo !== undefined) return e.rumo;
  const i = Math.round((e.x - quadC(0)) / PASSO), j = Math.round((e.z - quadC(0)) / PASSO), dx = e.x - quadC(i), dz = e.z - quadC(j);
  if (Math.abs(dz) >= Math.abs(dx) - 0.5) return dz >= 0 ? 0 : Math.PI;
  return dx >= 0 ? Math.PI / 2 : -Math.PI / 2;
}
export function predios3dPerto(px, pz, dt) {
  if (!modelos3d || !malhaPredios) return;
  if ((tempo3d -= dt) > 0) return; tempo3d = 0.7;
  const q = ctx.qualidade?.() || 'medio', max = q === 'ultra' ? 64 : q === 'alto' ? 40 : q === 'medio' ? 16 : 6, raio = q === 'ultra' ? 240 : q === 'alto' ? 190 : q === 'medio' ? 100 : 65;   // alto: um pouco menos de prédios 3D (o resto continua caixa, na mesma distância de visão)
  const perto = [];
  if (max) for (const k of chaves(px - raio - 20, pz - raio - 20, px + raio + 20, pz + raio + 20)) for (const i of gradeEd.get(k) || []) {
    const e = edificios[i]; if (cortados.has(i)) continue; const t = tipo3d(e); if (!t || !modelos3d[t]) continue;
    // folga para quem já está em 3D (fica até ~20 m mais longe): na borda do alcance o prédio não fica trocando de caixa
    // para 3D e de volta a cada passo (era um dos "pisca-piscas" andando pela cidade)
    const ja = em3d.has(i) ? 20 : 0, d = Math.hypot(e.x - px, e.z - pz) - ja; if (d < (e.tipo === 'favela' ? Math.min(raio, 45) : raio)) perto.push([d, i, t]);   // casas da favela: só as bem perto (modelo pesado)
  }
  perto.sort((a, b) => a[0] - b[0]);
  const novo = new Map(); const conta = {};
  let fav = 0; const maxFav = Math.max(4, Math.round(max * 0.5));
  for (const [, i, t] of perto) { if (novo.has(i)) continue; conta[t] = conta[t] || 0; if (novo.size >= max || conta[t] >= 48) continue; if (t.startsWith('favela_') && fav++ >= maxFav) continue; novo.set(i, t); conta[t]++; }
  // os que saíram voltam a ser caixa; os que entraram escondem a caixa (e telhado / detalhes)
  const mostrar = (i, vis) => {
    const e = edificios[i];
    // casa da favela em 3D: a caixa vira só o alicerce (do ponto mais baixo do barranco até o mais alto) e o modelo fica em cima
    malhaPredios.setMatrixAt(i, vis ? matrizPredio(e, cortados.has(i) ? Math.min(e.h, 2.2) : e.h) : e.solo ? matrizPredio(e, e.solo) : _m.makeScale(0, 0, 0));
    if (idxTelha.has(i)) malhaTelhas.setMatrixAt(idxTelha.get(i), matrizTelha(e, vis && !cortados.has(i)));
    for (const k of e.det) malhaDet.setMatrixAt(k, matrizDet(detalhes[k], vis && !cortados.has(i)));
  };
  for (const i of em3d.keys()) if (!novo.has(i)) mostrar(i, true);
  for (const i of novo.keys()) if (!em3d.has(i)) mostrar(i, false);
  em3d.clear(); for (const [i, t] of novo) em3d.set(i, t);
  malhaPredios.instanceMatrix.needsUpdate = true; malhaTelhas.instanceMatrix.needsUpdate = true; malhaDet.instanceMatrix.needsUpdate = true;
  const n = {}; for (const t of Object.keys(modelos3d)) n[t] = 0;
  for (const [i, t] of em3d) {
    const e = edificios[i], ang = rumo3d(e), lado = Math.abs(Math.sin(ang)) > 0.5;
    const meio = e.solo || 0;   // favela no barranco: o modelo começa em cima do alicerce (nada enterrado no morro)
    const h = e.tipo === 'casa' ? e.h + 1.5 : e.h - meio;
    _q.setFromAxisAngle(_v.set(0, 1, 0), ang);
    _m.compose(_v.set(e.x, e.y + meio, e.z), _q, _e.set(lado ? e.d : e.w, h, lado ? e.w : e.d));
    modelos3d[t].setMatrixAt(n[t]++, _m);
  }
  for (const [t, im] of Object.entries(modelos3d)) { im.count = n[t]; im.instanceMatrix.needsUpdate = true; }
}

// ---------------------------------------------------------------- minimapa (em metros; o chamador já aplicou a escala)
export function desenharMapa(g) {
  g.fillStyle = '#6d7076'; g.fillRect(-FIM_HORIZONTE, -FIM_HORIZONTE, FIM_HORIZONTE * 2, FIM_HORIZONTE * 2);
  g.fillStyle = '#b8a27f'; g.fillRect(-BORDA, -BORDA, BORDA * 2, BORDA * 2);
  g.fillStyle = '#8fb06a';
  for (const s of [-1, 1]) g.fillRect(-CORREDOR, s > 0 ? METADE : -FIM_HORIZONTE, CORREDOR * 2, FIM_HORIZONTE - METADE);
  g.fillStyle = '#86a95c';
  for (const s of [-1, 1]) g.fillRect(-1100, s > 0 ? FIM_HORIZONTE : -1300, 2200, 1300 - FIM_HORIZONTE);
  for (const e of extras) { g.fillStyle = e.cor; g.fillRect(e.x0, e.z0, e.x1 - e.x0, e.z1 - e.z0); }
  g.fillStyle = '#d8d1c3'; for (const [x, z, w, d] of calcadas) g.fillRect(x - w / 2, z - d / 2, w, d);
  g.fillStyle = '#7fa45a'; for (const [x, z, w, d] of gramados) g.fillRect(x - w / 2, z - d / 2, w, d);
  g.fillStyle = '#4a4e57'; for (const [x, z, w, d] of ruas) g.fillRect(x - w / 2, z - d / 2, w, d);
  for (const e of edificios) { g.fillStyle = e.tipo === 'casa' ? '#b3876a' : e.tipo === 'favela' ? '#b9774c' : e.y === 0 ? '#55585e' : '#9b968d'; g.fillRect(e.x - e.w / 2, e.z - e.d / 2, e.w, e.d); }
}

export function montar(contexto) {
  ctx = contexto;
  criarMateriais();
  gerarMetropole();
  gerarHorizonte();
  for (const c of CIDADES) gerarCidade(c);
  gerarFavelas();
  // árvores ao longo da faixa da ferrovia
  for (const s of [-1, 1]) for (let k = 0; k < 120; k++) {
    const x = (rnd() < 0.5 ? -1 : 1) * entre(13, CORREDOR - 3), z = s * entre(215, 835);
    if (Math.abs(z) > BORDA - 4 && Math.abs(z) < BORDA + 2) continue;
    arvore(x, z, entre(0.9, 1.4), Math.abs(z) < BORDA);
  }
  for (let k = 0; k < 220; k++) {
    const s = rnd() < 0.5 ? -1 : 1, x = entre(-900, 900), z = s * entre(FIM_HORIZONTE + 10, 890);
    if (Math.abs(x) < 30 || (Math.abs(x) < 55 && Math.abs(z) > 825)) continue;
    arvore(x, z, entre(1, 1.8), false);
  }
  montarChaos();
}
// chamado depois que a ferrovia acrescentou os prédios dela
// ---------------------------------------------------------------- mobiliário urbano: meio-fio, faixas, postes e carros
const pocas = [];                 // luz dos postes no chão (aparece à noite)
export const LUZES_POSTE = [];   // [x, z] da lâmpada de cada poste (gráfico ultra: luz que faz sombra de verdade)
export function poca(x, z, r = 5, cor, y) { pocas.push([x, z, r, cor, y]); }
let matCabeca = null, matPoca = null, matLed = null, matLampFav = null, matHalo = null;
// postes de concreto do Brasil: [x, z, ângulo do braço (para a rua), tipo de lâmpada 0 sódio / 1 LED, lado, trecho]
const POSTES = [];
export function posteCidade(x, z, rot, trecho = -1) { POSTES.push([x, z, rot, POSTES.length % 3 === 0 ? 1 : 0, 0, trecho >= 0 ? 100000 + trecho : -1]); }   // quarteirões do centro (antes era o GLB)
const dentroRet = (x, z, m) => ([rx, rz, w, d]) => Math.abs(x - rx) < w / 2 + m && Math.abs(z - rz) < d / 2 + m;
const naRuaRet = (x, z, m = 0) => ruas.some(dentroRet(x, z, m)) || ruasMorro.some(dentroRet(x, z, m));   // asfalto da cidade e dos morros
const emPredio = (x, z) => edificios.some((e) => Math.abs(x - e.x) < e.w / 2 + 0.3 && Math.abs(z - e.z) < e.d / 2 + 0.3);

function cruzamentos(r) {
  // centros das ruas que cruzam esta
  const [x, z, , , vert] = r, lista = [];
  for (const o of ruas) {
    if (o[4] === vert) continue;
    const [ox, oz, ow, od] = o;
    if (vert) { if (x >= ox - ow / 2 - 1 && x <= ox + ow / 2 + 1) lista.push(oz); }
    else if (z >= oz - od / 2 - 1 && z <= oz + od / 2 + 1) lista.push(ox);
  }
  return lista;
}
// trechos onde não se estaciona (o caminho dos ônibus): [[x,z],[x,z]] em metros
const corredores = [];
export function semEstacionar(pts) { for (let i = 0; i < pts.length - 1; i++) corredores.push([pts[i], pts[i + 1]]); }
function pertoDeCorredor(x, z) {
  for (const [[ax, az], [bx, bz]] of corredores) {
    const dx = bx - ax, dz = bz - az, l2 = dx * dx + dz * dz || 1, t = Math.max(0, Math.min(1, ((x - ax) * dx + (z - az) * dz) / l2));
    if (Math.hypot(x - (ax + dx * t), z - (az + dz * t)) < 3.4) return true;
  }
  return false;
}
// ---------------------------------------------------------------- postes do Brasil
// Cidade: poste de concreto de 9,6 m, braço curvo sobre a rua com luminária de sódio (laranja) ou LED (branca),
// cruzeta com a rede de cima, rede baixa, transformador em alguns, e os fios de um poste ao outro (mesma calçada).
// Favela: poste baixo e torto com lâmpada amarela fraca, fios embolados de um lado ao outro da rua, fios soltos
// pendurados e o "padrão" de cada casa recebendo um fio do poste.
const _p = new THREE.Vector3(), _d = new THREE.Vector3();
function catenaria(lista, a, b, flecha, n = 7) {   // fio caído entre dois pontos (segmentos de linha)
  for (let i = 0; i < n; i++) {
    const t0 = i / n, t1 = (i + 1) / n;
    for (const t of [t0, t1]) lista.push(a.x + (b.x - a.x) * t, a.y + (b.y - a.y) * t - flecha * 4 * t * (1 - t), a.z + (b.z - a.z) * t);
  }
}
function montarPostes(postes) {
  const { scene } = ctx;
  const H = 9.6, fios = [];
  const matConc = new THREE.MeshStandardMaterial({ color: '#a3a29b', roughness: 0.92 });
  const matFerro = new THREE.MeshStandardMaterial({ color: '#4b5056', roughness: 0.55, metalness: 0.5 });
  matCabeca = new THREE.MeshStandardMaterial({ color: '#f0d9b0', emissive: '#ff9a3c', emissiveIntensity: 0, roughness: 0.4 });
  matLed = new THREE.MeshStandardMaterial({ color: '#e9eef5', emissive: '#eaf2ff', emissiveIntensity: 0, roughness: 0.3 });
  // haste afinando (quadrada, como o duplo T), cruzeta, braço curvo e as duas luminárias
  const haste = new THREE.CylinderGeometry(0.1, 0.19, H, 4, 1).rotateY(Math.PI / 4).translate(0, H / 2, 0);
  const cruzeta = new THREE.BoxGeometry(0.1, 0.1, 2.0).translate(0, H - 0.5, -0.1);
  const curva = new THREE.QuadraticBezierCurve3(new THREE.Vector3(0, H - 1.4, 0.12), new THREE.Vector3(0, H + 0.1, 0.4), new THREE.Vector3(0, H - 0.15, 2.35));
  const braco = new THREE.TubeGeometry(curva, 10, 0.045, 5, false);
  const sodio = new THREE.SphereGeometry(0.26, 10, 6).scale(1, 0.42, 1.6).translate(0, H - 0.27, 2.45);
  const led = new THREE.BoxGeometry(0.34, 0.08, 0.62).translate(0, H - 0.24, 2.48);
  const trafo = new THREE.CylinderGeometry(0.32, 0.32, 1.0, 10).translate(0, H - 2.2, -0.48);
  const nS = postes.filter((p) => !p[3]).length, nL = postes.length - nS, nT = postes.filter((_, k) => k % 6 === 3).length;
  const iH = new THREE.InstancedMesh(haste, matConc, postes.length), iC = new THREE.InstancedMesh(cruzeta, matFerro, postes.length), iB = new THREE.InstancedMesh(braco, matFerro, postes.length);
  const iS = new THREE.InstancedMesh(sodio, matCabeca, Math.max(1, nS)), iL = new THREE.InstancedMesh(led, matLed, Math.max(1, nL)), iT = new THREE.InstancedMesh(trafo, matFerro, Math.max(1, nT));
  iS.count = nS; iL.count = nL; iT.count = nT;
  const halos = []; let s0i = 0, l0i = 0, t0i = 0;
  const local = (x, z, rot, lx, ly, lz) => _p.set(lx, ly, lz).applyAxisAngle(_d.set(0, 1, 0), rot).add(_v.set(x, 0.18, z)).clone();
  const porTrecho = new Map();
  postes.forEach(([x, z, rot, tipo, lado, trecho], k) => {
    _q.setFromAxisAngle(_e.set(0, 1, 0), rot); _m.compose(_v.set(x, 0.18, z), _q, _e.set(1, 1, 1));
    iH.setMatrixAt(k, _m); iC.setMatrixAt(k, _m); iB.setMatrixAt(k, _m);
    if (tipo) iL.setMatrixAt(l0i++, _m); else iS.setMatrixAt(s0i++, _m);
    if (k % 6 === 3) iT.setMatrixAt(t0i++, _m);
    addCol({ tipo: 'circ', x, z, r: 0.25 });
    const lamp = local(x, z, rot, 0, H - 0.3, 2.45);
    LUZES_POSTE.push([lamp.x, lamp.z, lamp.y]); halos.push(lamp.x, lamp.y - 0.12, lamp.z, tipo);
    const ch = local(x, z, rot, 0, 0, 2.45 + 1.2);
    poca(ch.x, ch.z, 7.5, tipo ? '#dfe8ff' : '#ffb25e');
    if (trecho >= 0) { const ch2 = `${trecho}:${lado}`; if (!porTrecho.has(ch2)) porTrecho.set(ch2, []); porTrecho.get(ch2).push([x, z, rot]); }
  });
  for (const m of [iH, iC, iB, iS, iL, iT]) { m.castShadow = m === iH; scene.add(m); }
  // fios: 3 na cruzeta (rede de cima) e 2 mais baixos (rede de baixo), de um poste ao próximo da mesma calçada
  for (const lista of porTrecho.values()) for (let i = 0; i < lista.length - 1; i++) {
    const [ax, az, ar] = lista[i], [bx, bz, br] = lista[i + 1];
    if (Math.hypot(bx - ax, bz - az) > 45) continue;
    for (const [lz, ly, fl] of [[-1.0, H - 0.45, 0.55], [-0.1, H - 0.45, 0.6], [0.75, H - 0.45, 0.55], [-0.2, H - 2.9, 0.45], [0.2, H - 3.2, 0.5]]) {
      catenaria(fios, local(ax, az, ar, 0, ly, lz), local(bx, bz, br, 0, ly, lz), fl);
    }
  }
  montarPostesFavela(fios, halos);
  const gf = new THREE.BufferGeometry(); gf.setAttribute('position', new THREE.Float32BufferAttribute(fios, 3));
  const lf = new THREE.LineSegments(gf, new THREE.LineBasicMaterial({ color: '#16181b' })); lf.frustumCulled = false; scene.add(lf);
  // brilho das lâmpadas à noite (um ponto que brilha, visto de longe)
  const hp = [], hc = [];
  for (let i = 0; i < halos.length; i += 4) { hp.push(halos[i], halos[i + 1], halos[i + 2]); const c = halos[i + 3] === 1 ? [0.85, 0.9, 1] : halos[i + 3] === 2 ? [0.75, 0.55, 0.22] : [1, 0.62, 0.25]; hc.push(...c); }
  const gh = new THREE.BufferGeometry(); gh.setAttribute('position', new THREE.Float32BufferAttribute(hp, 3)); gh.setAttribute('color', new THREE.Float32BufferAttribute(hc, 3));
  const th = ctx.texturaCanvas(64, (g, t) => { g.clearRect(0, 0, t, t); const gr = g.createRadialGradient(t / 2, t / 2, 0, t / 2, t / 2, t / 2); gr.addColorStop(0, 'rgba(255,255,255,1)'); gr.addColorStop(0.25, 'rgba(255,255,255,.55)'); gr.addColorStop(1, 'rgba(255,255,255,0)'); g.fillStyle = gr; g.fillRect(0, 0, t, t); });
  matHalo = new THREE.PointsMaterial({ map: th, size: 2.6, sizeAttenuation: true, vertexColors: true, transparent: true, opacity: 0, depthWrite: false, blending: THREE.AdditiveBlending, toneMapped: false });
  const ph = new THREE.Points(gh, matHalo); ph.visible = false; ph.frustumCulled = false; scene.add(ph); matHalo.userData.malha = ph;
}
function montarPostesFavela(fios, halos) {
  if (!favelasProntas) return;
  const { scene } = ctx, lista = [];
  let sf = 4242; const r = () => (sf = (sf * 16807) % 2147483647) / 2147483647;   // sorteio próprio (não mexe no resto do mapa)
  for (const [rx, rz, w, d, vert] of ruasMorro) {
    if (!naFavela(rx, rz)) continue;
    const a = vert ? rz - d / 2 : rx - w / 2, b = vert ? rz + d / 2 : rx + w / 2, meia = (vert ? w : d) / 2;
    let lado = r() < 0.5 ? 1 : -1;
    for (let t = a + 5; t < b - 4; t += 11 + r() * 5) {
      const px = vert ? rx + lado * (meia + 0.45) : t, pz = vert ? t : rz + lado * (meia + 0.45);
      if (!naFavela(px, pz) || naRuaRet(px, pz, 0.3)) { lado = -lado; continue; }   // nunca no asfalto (nos cruzamentos caía na outra rua)
      lista.push({ x: px, z: pz, y: altura(px, pz), rot: vert ? (lado > 0 ? -Math.PI / 2 : Math.PI / 2) : (lado > 0 ? Math.PI : 0),
        tx: (r() - 0.5) * 0.16, tz: (r() - 0.5) * 0.16, h: 6.2 + r() * 1.2 });
      lado = -lado;
    }
  }
  if (!lista.length) return;
  const matMad = new THREE.MeshStandardMaterial({ color: '#8d8a83', roughness: 0.95 });
  matLampFav = new THREE.MeshStandardMaterial({ color: '#e8d6a0', emissive: '#ffc35a', emissiveIntensity: 0, roughness: 0.5 });
  const iP = new THREE.InstancedMesh(new THREE.CylinderGeometry(0.08, 0.13, 1, 6).translate(0, 0.5, 0), matMad, lista.length);
  const iL = new THREE.InstancedMesh(new THREE.SphereGeometry(0.13, 8, 6), matLampFav, lista.length);
  const topo = (p) => _p.set(0, p.h, 0).applyEuler(new THREE.Euler(p.tx, 0, p.tz)).add(_v.set(p.x, p.y, p.z)).clone();
  lista.forEach((p, k) => {
    _q.setFromEuler(new THREE.Euler(p.tx, 0, p.tz)); _m.compose(_v.set(p.x, p.y, p.z), _q, _e.set(1, p.h, 1)); iP.setMatrixAt(k, _m);
    const tp = topo(p), lx = tp.x + Math.sin(p.rot) * 0.7, lz = tp.z + Math.cos(p.rot) * 0.7, ly = tp.y - 0.55;
    _m.compose(_v.set(lx, ly, lz), _q.identity(), _e.set(1, 1, 1)); iL.setMatrixAt(k, _m);
    fios.push(tp.x, tp.y - 0.4, tp.z, lx, ly + 0.12, lz);   // bracinho de fio até a lâmpada
    halos.push(lx, ly, lz, 2); poca(lx, lz, 3.6, '#c98a3a', altura(lx, lz) + 0.25);
    LUZES_POSTE.push([lx, lz, ly]);
    addCol({ tipo: 'circ', x: p.x, z: p.z, r: 0.2 });
    p.tp = tp;
  });
  iP.castShadow = true; scene.add(iP, iL);
  // fios embolados: de cada poste aos 2 seguintes (cruzando a rua), 3 a 6 fios cada, com caídas diferentes
  const desloca = (v, k) => v.clone().add(_d.set((r() - 0.5) * 0.3, -0.3 - k * 0.22 - r() * 0.2, (r() - 0.5) * 0.3));
  for (let i = 0; i < lista.length; i++) for (const j of [i + 1, i + 2]) {
    const a = lista[i], b = lista[j]; if (!b || Math.hypot(a.x - b.x, a.z - b.z) > 30) continue;
    const n = 3 + Math.floor(r() * 4);
    for (let k = 0; k < n; k++) catenaria(fios, desloca(a.tp, k), desloca(b.tp, k), 0.4 + r() * 1.3, 8);
  }
  // fio solto pendurado (um em cada 4 postes)
  for (const p of lista) if (r() < 0.25) {
    const a = p.tp.clone().add(_d.set(0, -0.6, 0)), m = a.clone().add(_d.set((r() - 0.5) * 1.6, -2.2 - r() * 1.5, (r() - 0.5) * 1.6));
    catenaria(fios, a, m, -0.4, 5);
  }
  // padrão de energia de cada casa perto de um poste: caixinha do medidor na frente da casa e o fio vindo do poste
  const casas = edificios.filter((e) => e.tipo === 'favela');
  const padroes = [];
  for (const e of casas) {
    let best = null, dm = 22;
    for (const p of lista) { const dd = Math.hypot(p.x - e.x, p.z - e.z); if (dd < dm) { dm = dd; best = p; } }
    if (!best) continue;
    const lad = Math.abs(Math.sin(e.rumo)) > 0.5, meia = (lad ? e.w : e.d) / 2 + 0.06, fx = Math.sin(e.rumo), fz = Math.cos(e.rumo), rx = Math.cos(e.rumo), rz = -Math.sin(e.rumo);
    const off = ((e.x * 7 + e.z * 13) % 1.4) - 0.7, bx = e.x + fx * meia + rx * off, bz = e.z + fz * meia + rz * off;
    const hTopo = e.y + Math.min(2.9 * (e.andares || 1), 5.6) - 0.2;
    padroes.push([bx, e.y + 1.7, bz, e.rumo]);
    catenaria(fios, best.tp.clone().add(_d.set(0, -0.5 - r() * 0.6, 0)), _p.set(bx, hTopo, bz).clone(), 0.25 + r() * 0.5, 6);
    fios.push(bx, hTopo, bz, bx, e.y + 1.95, bz);   // desce pela parede até o medidor
  }
  if (padroes.length) {
    const iM = new THREE.InstancedMesh(new THREE.BoxGeometry(0.32, 0.45, 0.16), new THREE.MeshStandardMaterial({ color: '#9aa1a6', roughness: 0.5, metalness: 0.4 }), padroes.length);
    padroes.forEach(([x, y, z, rot], k) => { _q.setFromAxisAngle(_e.set(0, 1, 0), rot); _m.compose(_v.set(x, y, z), _q, _e.set(1, 1, 1)); iM.setMatrixAt(k, _m); });
    scene.add(iM);
  }
}
function montarMobiliario() {
  const { scene } = ctx;
  // meio-fio em volta das calçadas
  const fios = [];
  for (const [x, z, w, d, y] of calcadas) {
    if (y < 0.15) continue;
    fios.push([x, z - d / 2 + 0.15, w, 0.3, y], [x, z + d / 2 - 0.15, w, 0.3, y], [x - w / 2 + 0.15, z, 0.3, d, y], [x + w / 2 - 0.15, z, 0.3, d, y]);
  }
  const mf = new THREE.InstancedMesh(new THREE.BoxGeometry(1, 1, 1), new THREE.MeshStandardMaterial({ color: '#a19b90', roughness: 0.85 }), fios.length);
  fios.forEach(([x, z, w, d, y], k) => { _m.compose(_v.set(x, (y + 0.03) / 2, z), _q.identity(), _e.set(w, y + 0.03, d)); mf.setMatrixAt(k, _m); });
  mf.receiveShadow = true; scene.add(mf);

  const faixas = [], postes = [], carros = [];
  for (const r of ruas) {
    const [x, z, w, d, vert] = r, cr = cruzamentos(r);
    const a = vert ? z - d / 2 : x - w / 2, b = vert ? z + d / 2 : x + w / 2, c = vert ? x : z;
    const longe = (t, m) => cr.every((q) => Math.abs(q - t) > m);
    const ponto = (t, lat) => (vert ? [c + lat, t] : [t, c + lat]);
    for (let t = a + 4; t < b - 3; t += 6) if (longe(t, RW / 2 + 6.5)) faixas.push([...ponto(t, 0), vert]);   // para antes da faixa de pedestre
    // postes de concreto: a cada 16 m, alternando os lados (32 m em cada calçada), sempre na calçada (nunca no
    // asfalto: a meia largura é a da própria rua, e o ponto tem que cair numa calçada e fora de outra rua)
    let lado = 1; const meia = vert ? w / 2 : d / 2, trecho = postes.length;
    for (let t = a + 8; t < b - 6; t += 16) {
      if (!longe(t, meia + 4)) { lado = -lado; continue; }
      const [px, pz] = ponto(t, lado * (meia + 0.75));
      if (naFavela(px, pz) || naRuaRet(px, pz, 0.4) || emPredio(px, pz)) { lado = -lado; continue; }
      postes.push([px, pz, vert ? (lado > 0 ? -Math.PI / 2 : Math.PI / 2) : (lado > 0 ? Math.PI : 0), rnd() < 0.4 ? 1 : 0, lado, trecho]);
      lado = -lado;
    }
    for (let t = a + 6; t < b - 6; t += 6.5) {
      if (rnd() > 0.3 || !longe(t, RW / 2 + 5)) continue;
      const lat = (rnd() < 0.5 ? -1 : 1) * (RW / 2 - 1.15);
      const [px, pz] = ponto(t, lat);
      if (pertoDeCorredor(px, pz) || naFavela(px, pz)) continue;   // faixa por onde passam os ônibus
      carros.push([px, pz, vert ? (lat > 0 ? 0 : Math.PI) : (lat > 0 ? Math.PI / 2 : -Math.PI / 2)]);
    }
  }
  // faixas tracejadas
  // faixa dupla amarela contínua (cada pedaço de 6 m vira dois traços de 10 cm)
  const fx = new THREE.InstancedMesh(new THREE.PlaneGeometry(1, 1).rotateX(-Math.PI / 2), new THREE.MeshStandardMaterial({ color: '#d9a21f', roughness: 0.8 }), faixas.length * 2);
  faixas.forEach(([x, z, vert], k) => {
    for (const [i, d] of [[0, -0.13], [1, 0.13]]) { _m.compose(_v.set(x + (vert ? d : 0), 0.032, z + (vert ? 0 : d)), _q.identity(), _e.set(vert ? 0.1 : 6, 1, vert ? 6 : 0.1)); fx.setMatrixAt(k * 2 + i, _m); }
  });
  fx.receiveShadow = true; scene.add(fx);
  // postes de concreto (cidade) e os da favela
  const dasRuas = postes.length;   // os dos quarteirões só entram onde não há poste de rua perto (sem duplicar)
  for (const p of POSTES) if (!postes.slice(0, dasRuas).some((q) => Math.abs(q[0] - p[0]) < 6 && Math.abs(q[1] - p[1]) < 6)) postes.push(p);
  montarPostes(postes);
  // luz dos postes no chão
  const tl = ctx.texturaCanvas(128, (g, t) => {
    g.clearRect(0, 0, t, t);
    const gr = g.createRadialGradient(t / 2, t / 2, 0, t / 2, t / 2, t / 2);
    gr.addColorStop(0, 'rgba(255,214,150,1)'); gr.addColorStop(0.45, 'rgba(255,190,120,.45)'); gr.addColorStop(1, 'rgba(255,170,90,0)');
    g.fillStyle = gr; g.fillRect(0, 0, t, t);
  });
  tl.wrapS = tl.wrapT = THREE.ClampToEdgeWrapping;
  matPoca = new THREE.MeshBasicMaterial({ map: tl, transparent: true, opacity: 0, depthWrite: false, blending: THREE.AdditiveBlending, toneMapped: false });
  const pc = new THREE.InstancedMesh(new THREE.PlaneGeometry(1, 1).rotateX(-Math.PI / 2), matPoca, pocas.length);
  pocas.forEach(([x, z, r, cor, y], k) => { _m.compose(_v.set(x, y ?? 0.21, z), _q.identity(), _e.set(r * 2, 1, r * 2)); pc.setMatrixAt(k, _m); pc.setColorAt(k, _c.set(cor || '#ffffff')); });
  pc.renderOrder = 2; pc.visible = false; scene.add(pc); matPoca.userData.malha = pc;
  // carros estacionados: caixinhas leves para todos; os mais perto do jogador trocam pelo modelo 3D
  const coresCarro = ['#c0392b', '#2c3e50', '#ecf0f1', '#7f8c8d', '#2980b9', '#16a085', '#f1c40f', '#8e44ad', '#d35400', '#1f1f1f', '#bdc3c7'];
  const corpo = new THREE.BoxGeometry(1.8, 0.62, 4.2).translate(0, 0.62, 0);
  const cabine = new THREE.BoxGeometry(1.58, 0.58, 2.1).translate(0, 1.2, -0.25);
  const rodaG = []; for (const sx of [-0.86, 0.86]) for (const sz of [-1.35, 1.35]) rodaG.push(new THREE.CylinderGeometry(0.34, 0.34, 0.24, 12).rotateZ(Math.PI / 2).translate(sx, 0.34, sz).toNonIndexed());
  const rodas = mergeSimples(rodaG);
  const ic = new THREE.InstancedMesh(corpo, new THREE.MeshStandardMaterial({ color: '#ffffff', roughness: 0.3, metalness: 0.45 }), carros.length);
  const iv = new THREE.InstancedMesh(cabine, new THREE.MeshStandardMaterial({ color: '#1d2730', roughness: 0.1, metalness: 0.6 }), carros.length);
  const ir = new THREE.InstancedMesh(rodas, new THREE.MeshStandardMaterial({ color: '#1b1c1f', roughness: 0.8 }), carros.length);
  carros.forEach(([x, z, rot], k) => {
    carros[k] = { x, z, rot, cor: escolher(coresCarro), tipo: (k * 7 + 3) % 3, perto: false };
    _q.setFromAxisAngle(_e.set(0, 1, 0), rot); _m.compose(_v.set(x, 0.02, z), _q, _e.set(1, 1, 1));
    ic.setMatrixAt(k, _m); iv.setMatrixAt(k, _m); ir.setMatrixAt(k, _m); ic.setColorAt(k, _c.set(carros[k].cor));
    const vert = Math.abs(Math.sin(rot)) < 0.5;
    carros[k].col = { tipo: 'caixa', x0: x - (vert ? 0.95 : 2.15), x1: x + (vert ? 0.95 : 2.15), z0: z - (vert ? 2.15 : 0.95), z1: z + (vert ? 2.15 : 0.95) }; addCol(carros[k].col);
  });
  for (const m of [ic, iv, ir]) { m.castShadow = true; m.receiveShadow = true; scene.add(m); }
  const MAX = window.matchMedia?.('(pointer: coarse)').matches ? 8 : 16;
  const glb = ['carro_popular', 'carro_suv', 'carro_esportivo'].map((n) => {
    const base = ctx.modelo?.(n); if (!base) return null;
    let malha = null; base.updateMatrixWorld(true);
    const inv = new THREE.Matrix4().copy(base.matrixWorld).invert();
    base.traverse((o) => { if (o.isMesh && !malha) malha = o; });
    if (!malha) return null;
    const geo = malha.geometry.clone().applyMatrix4(new THREE.Matrix4().multiplyMatrices(inv, malha.matrixWorld));
    const mat = [].concat(malha.material)[0].clone(); mat.color = new THREE.Color('#ffffff');
    const im = new THREE.InstancedMesh(geo, mat, 28); im.count = 0; im.receiveShadow = true; im.frustumCulled = false; scene.add(im);   // capacidade do ultra
    return im;
  });
  estacionados = { carros, caixas: [ic, iv, ir], glb, max: MAX, t: 0 };
}
let estacionados = null, arvoresLod = null;
// troca as árvores perto do jogador pelos modelos 3D
export function arvoresPerto(px, pz, dt) {
  const A = arvoresLod; if (!A || !A.glb.some(Boolean)) return;
  if ((A.t -= dt) > 0) return; A.t = 0.5;
  const conta = [0, 0, 0], novo = new Set();
  const ultra = /^(ultra|alto)$/.test(ctx.qualidade?.()), lim = ultra ? 220 : 120;   // alto vê tão longe quanto o ultra (árvores 3D até mais longe)
  const perto = []; A.info.forEach((a, k) => { const d = Math.abs(a.x - px) + Math.abs(a.z - pz); if (d < lim) perto.push([d, k]); });
  perto.sort((a, b) => a[0] - b[0]);
  for (const [, k] of perto) {
    const a = A.info[k], im = A.glb[a.tipo]; if (!im || conta[a.tipo] >= (ultra ? A.maxUltra : A.max)) continue;
    const e = a.sc * A.ESC[a.tipo];
    _q.setFromAxisAngle(_e.set(0, 1, 0), a.giro); _m.compose(_v.set(a.x, a.y, a.z), _q, _e.set(e, e, e));
    im.setMatrixAt(conta[a.tipo]++, _m); novo.add(k);
  }
  A.glb.forEach((im, i) => { if (im) { im.count = conta[i]; im.instanceMatrix.needsUpdate = true; } });
  let mT = false, mC = false, mP = false;
  A.info.forEach((a, k) => {
    const p = novo.has(k); if (p === a.perto) return; a.perto = p; mT = true;
    _q.setFromAxisAngle(_e.set(0, 1, 0), a.giro);
    const z0 = p ? 0 : 1;
    if (a.tipo === 1) {
      _m.compose(_v.set(a.x, a.y, a.z), _q, _e.set(a.sc * 0.8 * z0, a.sc * 0.7 * z0, a.sc * 0.8 * z0)); A.tronco.setMatrixAt(k, _m);
      _m.compose(_v.set(a.x, a.y + 0.6 * a.sc, a.z), _q, _e.set(a.sc * z0, a.sc * 1.1 * z0, a.sc * z0)); A.pinho.setMatrixAt(a.idx, _m); mP = true;
    } else {
      _m.compose(_v.set(a.x, a.y, a.z), _q, _e.set(a.sc * z0, a.sc * z0, a.sc * z0)); A.tronco.setMatrixAt(k, _m);
      _m.compose(_v.set(a.x, a.y + 2.55 * a.sc, a.z), _q, _e.set(a.sc * 1.05 * z0, a.sc * z0, a.sc * 1.05 * z0)); A.copa.setMatrixAt(a.idx, _m); mC = true;
    }
  });
  if (mT) A.tronco.instanceMatrix.needsUpdate = true;
  if (mC) A.copa.instanceMatrix.needsUpdate = true;
  if (mP) A.pinho.instanceMatrix.needsUpdate = true;
}
// troca as caixinhas perto do jogador pelos modelos 3D (chamado algumas vezes por segundo)
// carros estacionados na rua podem ser roubados: some do lugar e volta sozinho depois (o jogo controla o tempo)
export function carroRuaPerto(x, z, r = 3.2) {
  const E = estacionados; if (!E) return null;
  let melhor = null, md = r;
  E.carros.forEach((c, k) => { if (c.fora) return; const d = Math.hypot(c.x - x, c.z - z); if (d < md) { md = d; melhor = k; } });
  return melhor;
}
export const carroRua = (k) => estacionados?.carros[k] || null;
// carros estacionados nas vagas a até r metros (os que ainda estão na vaga)
export function carrosRuaRaio(x, z, r) { const l = []; estacionados?.carros.forEach((c, k) => { if (!c.fora && Math.hypot(c.x - x, c.z - z) <= r) l.push(k); }); return l; }
export function tirarCarroRua(k, fora) {
  const E = estacionados, c = E?.carros[k]; if (!c || !!c.fora === !!fora) return;
  c.fora = !!fora;
  if (c.col) { if (fora) { c.colOrig = { x0: c.col.x0, x1: c.col.x1, z0: c.col.z0, z1: c.col.z1 }; Object.assign(c.col, { x0: 1e7, x1: 1e7, z0: 1e7, z1: 1e7 }); } else if (c.colOrig) Object.assign(c.col, c.colOrig); }
  _q.setFromAxisAngle(_e.set(0, 1, 0), c.rot); _m.compose(_v.set(c.x, 0.02, c.z), _q, fora || c.perto ? _e.set(0, 0, 0) : _e.set(1, 1, 1));
  for (const m of E.caixas) { m.setMatrixAt(k, _m); m.instanceMatrix.needsUpdate = true; }
  E.t = 0;
}
export function carrosPerto(px, pz, dt) {
  const E = estacionados; if (!E || !E.glb.some(Boolean)) return;
  if ((E.t -= dt) > 0) return; E.t = 0.4;
  const ultra = /^(ultra|alto)$/.test(ctx.qualidade?.()), maxC = ultra ? 28 : E.max;   // ultra: carros 3D até mais longe
  const perto = E.carros.map((c, k) => [c.fora ? 1e9 : Math.hypot(c.x - px, c.z - pz), k]).filter(([d]) => d < (ultra ? 130 : 70)).sort((a, b) => a[0] - b[0]).slice(0, maxC * 2);
  const conta = E.glb.map(() => 0), novo = new Set();
  for (const [, k] of perto) {
    const c = E.carros[k], im = E.glb[c.tipo]; if (!im || conta[c.tipo] >= maxC) continue;
    _q.setFromAxisAngle(_e.set(0, 1, 0), c.rot); _m.compose(_v.set(c.x, 0.02, c.z), _q, _e.set(1, 1, 1));
    im.setMatrixAt(conta[c.tipo], _m); im.setColorAt(conta[c.tipo], _c.set('#ffffff').lerp(new THREE.Color(c.cor), 0.25)); conta[c.tipo]++;   // tinta leve (forte, as rodas ficavam roxas/coloridas)
    novo.add(k);
  }
  E.glb.forEach((im, i) => { if (!im) return; im.count = conta[i]; im.instanceMatrix.needsUpdate = true; if (im.instanceColor) im.instanceColor.needsUpdate = true; });
  // esconde (escala 0) as caixinhas que viraram modelo e mostra de volta as que saíram
  let mudou = false;
  E.carros.forEach((c, k) => {
    const p = novo.has(k); if (p === c.perto) return; c.perto = p; mudou = true;
    _q.setFromAxisAngle(_e.set(0, 1, 0), c.rot); _m.compose(_v.set(c.x, 0.02, c.z), _q, p || c.fora ? _e.set(0, 0, 0) : _e.set(1, 1, 1));
    for (const m of E.caixas) m.setMatrixAt(k, _m);
  });
  if (mudou) for (const m of E.caixas) m.instanceMatrix.needsUpdate = true;
}
function mergeSimples(lista) {
  let n = 0; for (const g of lista) n += g.attributes.position.count;
  const pos = new Float32Array(n * 3), nor = new Float32Array(n * 3); let o = 0;
  for (const g of lista) { pos.set(g.attributes.position.array, o * 3); nor.set(g.attributes.normal.array, o * 3); o += g.attributes.position.count; }
  const r = new THREE.BufferGeometry(); r.setAttribute('position', new THREE.BufferAttribute(pos, 3)); r.setAttribute('normal', new THREE.BufferAttribute(nor, 3)); return r;
}

// noite: 0 = dia claro, 1 = noite fechada
export function definirNoite(n) {
  UNI.uNoite.value = n;
  if (matJanelas) { matJanelas.opacity = Math.min(1, n * 1.3) * 0.95; malhaJanelas.visible = n > 0.05; }
  if (matCabeca) matCabeca.emissiveIntensity = n * 2.2;
  if (matLed) matLed.emissiveIntensity = n * 2.4;
  if (matLampFav) matLampFav.emissiveIntensity = n * 1.6;
  if (matHalo) { matHalo.opacity = n * 0.85; matHalo.userData.malha.visible = n > 0.05; }
  if (matPoca) { matPoca.opacity = n * 0.6; matPoca.userData.malha.visible = n > 0.02; }
}
// chuva: asfalto e calçada escurecem e ficam lisos (refletem o céu e as luzes)
let molhadoAntes = -1;
export function molhar(f) {
  if (!MAT || Math.abs(f - molhadoAntes) < 0.01) return; molhadoAntes = f;
  MAT.asfalto.roughness = 0.88 - 0.62 * f; MAT.asfalto.color.setScalar(1 - 0.3 * f); MAT.asfalto.envMapIntensity = 1 + 1.6 * f;
  MAT.calcada.roughness = 0.92 - 0.45 * f; MAT.calcada.color.setScalar(1 - 0.2 * f); MAT.calcada.envMapIntensity = 1 + 0.8 * f;
}
// gráfico ultra: água mais lisa e espelhada, ondas mais marcadas e andando mais rápido (reflete o céu e o sol)
export function atualizar(dt) {
  const A = MAT?.agua; if (!A?.normalMap) return;
  const ultra = ctx?.qualidade?.() === 'ultra';
  A.normalMap.offset.x += dt * (ultra ? 0.011 : 0.004); A.normalMap.offset.y += dt * (ultra ? 0.007 : 0.0025);
  if (A.userData.ultra !== ultra) {
    A.userData.ultra = ultra;
    A.roughness = ultra ? 0.04 : 0.12; A.metalness = ultra ? 0.4 : 0.25; A.envMapIntensity = ultra ? 1.8 : 1;
    A.normalScale.set(ultra ? 1.15 : 0.6, ultra ? 1.15 : 0.6); A.color.set(ultra ? '#2f6f99' : '#3e7ea6');
  }
}

// semáforos nos cruzamentos do centro e hidrantes nas esquinas dos quarteirões do centro
function planejarProps() {
  // existe rua aqui? (a avenida do meio só no centro; ferrovia corta as horizontais fora do centro; territórios cortam algumas)
  const temV = (i, z) => (i === 2 ? Math.abs(z) <= METADE : !((i === -1 || i === N + 1) && Math.abs(z) < ruaC(3)));
  const temH = (j, x) => { const centro = j >= 0 && j <= N; if (!centro && Math.abs(x) < CORREDOR + 1) return false; if (j === 2 && Math.abs(x) > METADE && Math.abs(x) < -ruaC(-2) + RW / 2 + 6) return false; return true; };
  const d = RW / 2 + 0.9;
  for (let i = MI; i <= MA + 1; i++) for (let j = MI; j <= MA + 1; j++) {
    const x = ruaC(i), z = ruaC(j); if (!temV(i, z) || !temH(j, x)) continue;
    CRUZAMENTOS.push({ x, z }); for (const [sx, sz] of [[1, 1], [-1, -1], [1, -1], [-1, 1]]) addCol({ tipo: 'circ', x: x + sx * d, z: z + sz * d, r: 0.25 });
  }
  for (const c of CIDADES) for (const cx of CID.colunas) for (const rz of CID.ruas) {   // cidades
    const z = c.s * rz;
    if (naFavela(cx, z)) continue;
    CRUZAMENTOS.push({ x: cx, z }); for (const [sx, sz] of [[1, 1], [-1, -1], [1, -1], [-1, 1]]) addCol({ tipo: 'circ', x: cx + sx * d, z: z + sz * d, r: 0.25 });
  }
  // hidrantes: dois por quarteirão (metrópole e cidades)
  const hid = (bx, bz) => { const dd = QB / 2 - 1.1; for (const [sx, sz] of [[1, -1], [-1, 1]]) { const px = bx + sx * dd, pz = bz + sz * dd; PROPS.hidrante.push([px, pz, sx > 0 ? 0 : Math.PI]); addCol({ tipo: 'circ', x: px, z: pz, r: 0.3 }); } };
  for (let i = MI; i <= MA; i++) for (let j = MI; j <= MA; j++) if ((i >= 0 && i < N && j >= 0 && j < N) || blocosMetro.has(i + ',' + j)) hid(quadC(i), quadC(j));
  for (const c of CIDADES) for (const bz of CID.blocos) for (const bx of CID.xs) hid(bx, c.s * bz);
}
// recebe o modelo leve (GLB) e espalha cópias com uma InstancedMesh só (um desenho para todos)
const ALTURA_PROP = { banco: 0.9, hidrante: 0.85, semaforo: 4.4 };
export function montarProps(nome, cenaGlb, scene) {
  const lista = PROPS[nome]; if (!lista?.length) return;
  let malha = null; cenaGlb.traverse((o) => { if (!malha && o.isMesh) malha = o; }); if (!malha) return;
  const g = malha.geometry.clone(); malha.updateWorldMatrix(true, false); g.applyMatrix4(malha.matrixWorld);
  g.computeBoundingBox(); const b = g.boundingBox, alt = b.max.y - b.min.y || 1, esc = ALTURA_PROP[nome] / alt;
  g.translate(-(b.min.x + b.max.x) / 2, -b.min.y, -(b.min.z + b.max.z) / 2); g.scale(esc, esc, esc);
  const mat = new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.75, metalness: nome === 'semaforo' ? 0.3 : 0.05 });
  const max = Math.min(lista.length, nome === 'banco' ? 40 : 56);
  const im = new THREE.InstancedMesh(g, mat, max); im.count = 0; im.frustumCulled = false;
  im.castShadow = nome !== 'hidrante'; im.receiveShadow = true; scene.add(im);
  propsLod[nome] = { im, lista, max, y: lista.map(([x, z]) => alturaChaoMundo(x, z)) };
}
// a cada meio segundo, cada tipo de objeto mostra só as cópias mais perto do jogador (a cidade toda tem centenas)
const propsLod = {}; let tempoProps = 0;
export function propsPerto(px, pz, dt) {
  if ((tempoProps -= dt) > 0) return; tempoProps = 0.5;
  for (const P of Object.values(propsLod)) {
    const perto = []; P.lista.forEach(([x, z], k) => { const d = Math.abs(x - px) + Math.abs(z - pz); if (d < 190) perto.push([d, k]); });
    perto.sort((a, b) => a[0] - b[0]); const n = Math.min(P.max, perto.length);
    for (let i = 0; i < n; i++) { const k = perto[i][1], [x, z, a] = P.lista[k]; _q.setFromAxisAngle(_v.set(0, 1, 0), a); _m.compose(_v.set(x, P.y[k], z), _q, _e.set(1, 1, 1)); P.im.setMatrixAt(i, _m); }
    P.im.count = n; P.im.instanceMatrix.needsUpdate = true;
  }
}
const alturaChaoMundo = (x, z) => { for (const [cx, cz, w, d, y] of calcadas) if (Math.abs(x - cx) <= w / 2 && Math.abs(z - cz) <= d / 2) return y; return 0.18; };
export const alturaCalcada = (x, z) => alturaChaoMundo(x, z);
// quarteirões (calçada inteira de QB x QB): onde ficam os guichês de estacionamento. [x, z, meia, altura da calçada]
export function listaQuadras() {
  const vistos = new Set(), r = [];
  for (const [x, z, w, d, y] of calcadas) {
    if (Math.abs(w - QB) > 0.5 || Math.abs(d - QB) > 0.5 || naFavela(x, z)) continue;
    const k = `${Math.round(x)},${Math.round(z)}`; if (vistos.has(k)) continue; vistos.add(k);
    r.push([x, z, QB / 2, y]);
  }
  return r;
}
// ponto na rua mais perto (na faixa junto ao meio-fio, do lado de quem está pedindo): onde o mecânico deixa o carro
export function pontoRuaPerto(x, z) {
  let m = null, dm = Infinity;
  for (const [rx, rz, w, d, vert] of ruas) {
    const cx = Math.max(rx - w / 2, Math.min(rx + w / 2, x)), cz = Math.max(rz - d / 2, Math.min(rz + d / 2, z)), dd = Math.hypot(cx - x, cz - z);
    if (dd < dm) { dm = dd; m = vert ? { x: rx + Math.sign(x - rx || 1) * (w / 2 - 1.3), z: cz } : { x: cx, z: rz + Math.sign(z - rz || 1) * (d / 2 - 1.3) }; }
  }
  return dm < 120 ? m : null;
}
export function finalizar() { planejarProps(); montarMobiliario(); montarMalhas(); }

// ---------------------------------------------------------------- ruas de verdade: "é rua?" e caminho só pelas ruas
// (usa os retângulos de asfalto desenhados; vale para a Metrópole, o horizonte e as cidades vizinhas)
// as ruas do centro (4 x 4 quarteirões) são desenhadas pelo main.js; entram aqui só para a conta
const ruasCentro = []; for (let i = 0; i <= N; i++) ruasCentro.push([0, ruaC(i), TOTAL, RW, false], [ruaC(i), 0, RW, TOTAL, true]);
const todasRuas = () => (ruas.length ? ruas.concat(ruasCentro, ruasMorro) : ruas);
export function naRua(x, z, m = 0, vert) {   // vert: só as ruas verticais (true) ou horizontais (false)
  for (const [rx, rz, w, d, v] of todasRuas()) if (vert !== undefined && v !== vert) continue; else if (Math.abs(x - rx) <= w / 2 + m && Math.abs(z - rz) <= d / 2 + m) return true;
  return false;
}
let grafo = null;
function montarGrafo() {
  // cada rua vira uma linha no meio dela; os nós ficam nas pontas e nos cruzamentos
  const segs = todasRuas().map(([x, z, w, d, vert]) => (vert ? { v: true, c: x, a: z - d / 2, b: z + d / 2, larg: w } : { v: false, c: z, a: x - w / 2, b: x + w / 2, larg: d }));
  for (const s of segs) s.nos = [s.a, s.b];
  for (let i = 0; i < segs.length; i++) for (let j = i + 1; j < segs.length; j++) {
    const s = segs[i], t = segs[j];
    if (s.v !== t.v) {   // cruzamento
      const h = s.v ? t : s, v = s.v ? s : t;
      if (v.c >= h.a - h.larg && v.c <= h.b + h.larg && h.c >= v.a - v.larg && h.c <= v.b + v.larg) { h.nos.push(Math.min(h.b, Math.max(h.a, v.c))); v.nos.push(Math.min(v.b, Math.max(v.a, h.c))); }
    } else if (Math.abs(s.c - t.c) < 1 && s.a <= t.b + 2 && t.a <= s.b + 2) {   // mesma rua em pedaços
      s.nos.push(Math.min(s.b, Math.max(s.a, t.a)), Math.min(s.b, Math.max(s.a, t.b))); t.nos.push(Math.min(t.b, Math.max(t.a, s.a)), Math.min(t.b, Math.max(t.a, s.b)));
    }
  }
  const nos = new Map(), chave = (x, z) => `${Math.round(x / 2)},${Math.round(z / 2)}`;   // pontas a menos de ~2 m viram o mesmo nó
  const no = (x, z) => { const k = chave(x, z); let n = nos.get(k); if (!n) { n = { x, z, viz: [] }; nos.set(k, n); } return n; };
  for (const s of segs) {
    s.nos = [...new Set(s.nos.map((u) => Math.round(u * 10) / 10))].sort((p, q) => p - q);
    s.lista = s.nos.map((u) => (s.v ? no(s.c, u) : no(u, s.c)));
    for (let k = 1; k < s.lista.length; k++) { const p = s.lista[k - 1], q = s.lista[k]; if (p === q) continue; const d = Math.hypot(p.x - q.x, p.z - q.z); p.viz.push([q, d]); q.viz.push([p, d]); }
  }
  grafo = { segs, nos: [...nos.values()] };
}
// ponto da rua mais perto (no meio dela) e os nós vizinhos naquele trecho
function entrada(x, z) {
  let m = null, dm = Infinity;
  for (const s of grafo.segs) {
    const u = Math.min(s.b, Math.max(s.a, s.v ? z : x)), px = s.v ? s.c : u, pz = s.v ? u : s.c, d = Math.hypot(px - x, pz - z);
    if (d < dm) { dm = d; m = { s, u, x: px, z: pz, d }; }
  }
  if (!m) return null;
  const L = m.s.lista, us = m.s.nos; let k = 1; while (k < us.length - 1 && us[k] < m.u) k++;
  m.viz = [[L[k - 1], Math.abs(m.u - us[k - 1])], [L[k], Math.abs(us[k] - m.u)]];
  return m;
}
// ruas fechadas por veículo em chamas (ou carcaça): os caminhos desviam. Perto da saída e da chegada não conta
// (o caminhão dos bombeiros precisa chegar no fogo; quem já está ali sai).
let bloqueios = [];
export function definirBloqueios(l) { bloqueios = l || []; }
export const bloqueiosRua = () => bloqueios;
export const distTrecho = (k, p, q) => distSeg(k, p, q);
function distSeg(k, p, q) {
  const dx = q.x - p.x, dz = q.z - p.z, L2 = dx * dx + dz * dz || 1, t = Math.max(0, Math.min(1, ((k.x - p.x) * dx + (k.z - p.z) * dz) / L2));
  return Math.hypot(k.x - p.x - dx * t, k.z - p.z - dz * t);
}
function trechoFechado(p, q, a, b) {
  for (const k of bloqueios) {
    if (Math.hypot(k.x - a.x, k.z - a.z) < 15 || Math.hypot(k.x - b.x, k.z - b.z) < 15) continue;
    if (distSeg(k, p, q) < (k.r || 3) + 3) return true;
  }
  return false;
}
// caminho pelas ruas de a até o meio-fio mais perto de b: [{x,z}, ...] (null se não houver ligação)
export function caminhoRuas(a, b) {
  if (!ruas.length) return null;
  if (!grafo) montarGrafo();
  const ea = entrada(a.x, a.z), eb = entrada(b.x, b.z);
  if (!ea || !eb || ea.d > 80 || eb.d > 80) return null;
  if (ea.s === eb.s && !(bloqueios.length && trechoFechado(ea, eb, a, b))) return [{ x: a.x, z: a.z }, { x: ea.x, z: ea.z }, { x: eb.x, z: eb.z }];
  // Dijkstra simples (poucos nós)
  const dist = new Map(), ant = new Map(), fila = [];
  for (const [n, d] of ea.viz) { if (bloqueios.length && trechoFechado(ea, n, a, b)) continue; if (!(dist.get(n) <= d)) { dist.set(n, d); ant.set(n, null); fila.push(n); } }
  const fim = new Map(eb.viz.filter(([n]) => !(bloqueios.length && trechoFechado(n, eb, a, b))).map(([n, d]) => [n, d]));
  let melhor = null, dmelhor = Infinity;
  while (fila.length) {
    let i = 0; for (let k = 1; k < fila.length; k++) if (dist.get(fila[k]) < dist.get(fila[i])) i = k;
    const n = fila.splice(i, 1)[0], dn = dist.get(n);
    if (dn >= dmelhor) break;
    if (fim.has(n) && dn + fim.get(n) < dmelhor) { dmelhor = dn + fim.get(n); melhor = n; }
    for (const [q, d] of n.viz) { if (bloqueios.length && trechoFechado(n, q, a, b)) continue; const nd = dn + d; if (!(dist.get(q) <= nd)) { if (!dist.has(q)) fila.push(q); dist.set(q, nd); ant.set(q, n); } }
  }
  if (!melhor) return null;
  const meio = []; for (let n = melhor; n; n = ant.get(n)) meio.unshift({ x: n.x, z: n.z });
  return [{ x: a.x, z: a.z }, { x: ea.x, z: ea.z }, ...meio, { x: eb.x, z: eb.z }];
}
export const listaRuas = () => ruas;

// ---------------------------------------------------------------- grama em tufos (perto do jogador, só nos gramados)
// Tufo feito por código (folhas finas e curvas, base escura e ponta clara): o tufo do Meshy tinha 684 mil triângulos
// e as folhas finas se desfazem quando simplificadas. Cada tufo tem ~100 triângulos e todos saem num desenho só.
let tufos = null;
function geoTufo() {
  const P = [], C = [], I = [], base = new THREE.Color('#3f6f2a'), meio = new THREE.Color('#5f9638'), ponta = new THREE.Color('#9cc95a');
  let r = 7; const rnd = () => ((r = (r * 16807) % 2147483647) / 2147483647);
  for (let f = 0; f < 18; f++) {
    const a = rnd() * Math.PI * 2, d = rnd() * 0.18, h = 0.16 + rnd() * 0.2, w = 0.025 + rnd() * 0.015, curva = 0.05 + rnd() * 0.1, giro = a + (rnd() - 0.5);
    const bx = Math.cos(a) * d, bz = Math.sin(a) * d, dx = Math.cos(a), dz = Math.sin(a), px = -Math.sin(giro), pz = Math.cos(giro);
    const i0 = P.length / 3;
    for (let k = 0; k <= 3; k++) {
      const t = k / 3, larg = w * (1 - t * 0.85), y = h * t, off = curva * t * t;
      for (const sx of [-1, 1]) { P.push(bx + dx * off + px * larg * sx, y, bz + dz * off + pz * larg * sx); const c = t < 0.5 ? base.clone().lerp(meio, t * 2) : meio.clone().lerp(ponta, (t - 0.5) * 2); C.push(c.r, c.g, c.b); }
    }
    for (let k = 0; k < 3; k++) { const q = i0 + k * 2; I.push(q, q + 1, q + 2, q + 1, q + 3, q + 2); }
  }
  const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.Float32BufferAttribute(P, 3)); g.setAttribute('color', new THREE.Float32BufferAttribute(C, 3)); g.setIndex(I); g.computeVertexNormals();
  // normais para cima: a grama fica iluminada por igual (sem folha preta virada para o lado da sombra)
  const n = g.attributes.normal; for (let i = 0; i < n.count; i++) n.setXYZ(i, n.getX(i) * 0.3, 1, n.getZ(i) * 0.3); n.needsUpdate = true;
  return g;
}
export function gramaPerto(px, pz, dt) {
  const q = ctx?.qualidade?.() || 'medio', max = { ultra: 1100, alto: 700, medio: 260 }[q] || 0, raio = { ultra: 46, alto: 38, medio: 24 }[q] || 0;
  if (!tufos) {
    if (!max || !gramados.length) return;
    const im = new THREE.InstancedMesh(geoTufo(), new THREE.MeshStandardMaterial({ vertexColors: true, side: THREE.DoubleSide, roughness: 0.95 }), 1100);
    im.count = 0; im.frustumCulled = false; im.receiveShadow = true; ctx.scene.add(im);
    tufos = { im, x: 1e9, z: 1e9, t: 0, q: '' };
  }
  const T = tufos;
  if ((T.t -= dt) > 0) return; T.t = 0.4;
  if (Math.hypot(px - T.x, pz - T.z) < 3 && T.q === q) return;
  T.x = px; T.z = pz; T.q = q;
  const PASSO = 1.7, perto = gramados.filter(([x, z, w, d]) => Math.abs(x - px) < raio + w / 2 && Math.abs(z - pz) < raio + d / 2);
  let n = 0;
  for (const [gx, gz, w, d] of perto) {
    const x0 = Math.max(gx - w / 2 + 0.4, px - raio), x1 = Math.min(gx + w / 2 - 0.4, px + raio), z0 = Math.max(gz - d / 2 + 0.4, pz - raio), z1 = Math.min(gz + d / 2 - 0.4, pz + raio);
    for (let x = Math.ceil(x0 / PASSO) * PASSO; x <= x1 && n < max; x += PASSO) for (let z = Math.ceil(z0 / PASSO) * PASSO; z <= z1 && n < max; z += PASSO) {
      const h = Math.abs(Math.sin(x * 12.9898 + z * 78.233) * 43758.5453) % 1, h2 = Math.abs(Math.sin(x * 39.34 + z * 11.13) * 24634.63) % 1;
      if (h < 0.35) continue;   // nem toda célula tem tufo (fica natural)
      const tx = x + (h2 - 0.5) * PASSO * 0.8, tz = z + (h - 0.5) * PASSO * 0.8;
      if (Math.hypot(tx - px, tz - pz) > raio) continue;
      const e = 0.75 + h2 * 0.45;
      _q.setFromAxisAngle(_e.set(0, 1, 0), h * 6.28); _m.compose(_v.set(tx, (altura(tx, tz) ?? 0) + 0.18, tz), _q, _e.set(e, e * (0.8 + h * 0.5), e));
      T.im.setMatrixAt(n++, _m);
    }
  }
  T.im.count = n; T.im.instanceMatrix.needsUpdate = true;
}
export const listaGramados = () => gramados;
