// Rede: contas, perfis (Supabase) e tempo real (Supabase Realtime)
import { createClient } from '@supabase/supabase-js';

export const SUPABASE_URL = 'https://uqiiztzdkjyewhdikabd.supabase.co';
export const SUPABASE_CHAVE = 'sb_publishable_diSzJqF0E4FLIALaI5UQLg_JUGJehS3';

export const sb = createClient(SUPABASE_URL, SUPABASE_CHAVE, {
  auth: { persistSession: true, autoRefreshToken: true },
  realtime: { params: { eventsPerSecond: 20 } },
});

const ERROS = {
  'Invalid login credentials': 'E-mail ou senha incorretos.',
  'User already registered': 'Esse e-mail já tem conta. Use Entrar.',
  'Email not confirmed': 'Confirme o e-mail antes de entrar (veja sua caixa de entrada).',
  'Password should be at least 6 characters.': 'A senha precisa ter pelo menos 6 caracteres.',
};
function traduzir(e) {
  if (!e) return '';
  for (const [k, v] of Object.entries(ERROS)) if (e.message?.startsWith(k)) return v;
  if (e.code === '23505') return 'Esse nome já está em uso. Escolha outro.';
  if (e.message?.includes('rate limit')) return 'Muitas tentativas. Espere um pouco e tente de novo.';
  return e.message || String(e);
}

export async function sessaoAtual() {
  const { data } = await sb.auth.getSession();
  return data.session;
}
export async function entrar(email, senha) {
  const { data, error } = await sb.auth.signInWithPassword({ email, password: senha });
  if (error) throw new Error(traduzir(error));
  return data.session;
}
export async function cadastrar(email, senha) {
  const { data, error } = await sb.auth.signUp({ email, password: senha });
  if (error) throw new Error(traduzir(error));
  if (!data.session) throw new Error('Conta criada! Confirme pelo link enviado ao seu e-mail e depois toque em Entrar.');
  return data.session;
}
export async function sair() { await sb.auth.signOut(); }

export async function carregarPerfil(id) {
  const { data, error } = await sb.from('perfis').select('*').eq('id', id).maybeSingle();
  if (error) throw new Error(traduzir(error));
  return data;
}
export async function criarPerfil(id, nome, personagem) {
  const { data, error } = await sb.from('perfis').insert({ id, nome, personagem }).select().single();
  if (error) throw new Error(traduzir(error));
  return data;
}
export async function salvarPosicao(id, x, z, fome) {
  const dados = { pos_x: x, pos_z: z, visto_em: new Date().toISOString() };
  if (typeof fome === 'number') dados.fome = Math.max(0, Math.min(100, Math.round(fome * 10) / 10));
  await sb.from('perfis').update(dados).eq('id', id);
}

// ---------------------------------------------------------------- tempo real
// Um canal para a cidade inteira: presença (quem está online) e mensagens de posição/ações.
export function conectarCidade(perfil, eventos) {
  const canal = sb.channel('cidade', {
    config: { presence: { key: perfil.id }, broadcast: { self: false, ack: false } },
  });
  canal.on('presence', { event: 'sync' }, () => {
    const estado = canal.presenceState();
    const lista = {};
    for (const [id, metas] of Object.entries(estado)) if (metas[0]) lista[id] = metas[0];
    eventos.presenca?.(lista);
  });
  canal.on('broadcast', { event: 'pos' }, ({ payload }) => eventos.pos?.(payload));
  canal.on('broadcast', { event: 'tiro' }, ({ payload }) => eventos.tiro?.(payload));
  canal.on('broadcast', { event: 'dano' }, ({ payload }) => eventos.dano?.(payload));
  canal.subscribe(async (status) => {
    if (status === 'SUBSCRIBED') {
      await canal.track(eventos.meta ? eventos.meta() : { nome: perfil.nome, personagem: perfil.personagem, cargo: perfil.cargo });
      eventos.conectado?.(true);
    } else if (status === 'CHANNEL_ERROR' || status === 'TIMED_OUT' || status === 'CLOSED') {
      eventos.conectado?.(false);
    }
  });
  return {
    enviar(evento, payload) { canal.send({ type: 'broadcast', event: evento, payload }); },
    rastrear(meta) { return canal.track(meta); },
    fechar() { sb.removeChannel(canal); },
  };
}

// ---------------------------------------------------------------- escuta do próprio perfil e de comandos
export function escutarMeuPerfil(id, eventos) {
  const canal = sb.channel('eu-' + id)
    .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'perfis', filter: `id=eq.${id}` }, (p) => eventos.perfil?.(p.new))
    .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'comandos', filter: `alvo=eq.${id}` }, (p) => eventos.comando?.(p.new))
    .on('postgres_changes', { event: '*', schema: 'public', table: 'inventario', filter: `dono=eq.${id}` }, () => eventos.inventario?.())
    .subscribe();
  return () => sb.removeChannel(canal);
}

// ---------------------------------------------------------------- painel (todas verificadas no banco)
async function rpc(nome, args = {}) {
  const { data, error } = await sb.rpc(nome, args);
  if (error) throw new Error(traduzirRpc(error.message));
  return data;
}
function traduzirRpc(m) {
  const t = {
    'sem permissao': 'Você não tem esse poder.',
    'voce nao pode banir esse jogador': 'Você não pode banir esse jogador.',
    'voce nao pode desbanir esse jogador': 'Você não pode desbanir esse jogador.',
    'voce nao pode algemar esse jogador': 'Você não pode algemar esse jogador.',
    'voce nao pode prender esse jogador': 'Você não pode prender esse jogador.',
    'voce nao pode mover esse jogador': 'Você não pode mover esse jogador.',
    'voce nao pode mudar as moedas desse jogador': 'Você não pode mudar as moedas desse jogador.',
    'moderador nao muda as proprias moedas': 'Moderador não pode mudar as próprias moedas.',
    'algemas nao funcionam na equipe': 'Algemas não funcionam em moderadores nem no administrador.',
    'a equipe nao pode ser presa': 'Moderadores e o administrador não podem ser presos.',
    'so o administrador pode fazer isso': 'Só o administrador pode fazer isso.',
    'voce nao pode mudar o proprio cargo': 'Você não pode mudar o próprio cargo.',
    'nao e possivel mudar outro administrador': 'Não é possível mudar outro administrador.',
    'so a equipe troca de skin de graca': 'Só a equipe troca de skin de graça.',
    'tempo invalido': 'Tempo inválido (0 a 1440 minutos).',
    'valor muito alto': 'Valor muito alto.',
    'jogador nao encontrado': 'Jogador não encontrado.',
    'voce esta preso': 'Você não pode fazer isso preso ou algemado.',
    'mochila cheia de sucata': 'Sua mochila já está cheia de sucata. Venda na loja.',
    'mochila cheia': 'Sua mochila está cheia desse item.',
    'nenhuma caixa embalada': 'Essa caixa não foi embalada por você.',
    'entrega rapida demais': 'Entrega rápida demais. Tente de novo em instantes.',
    'moedas insuficientes': 'Moedas insuficientes.',
    'itens insuficientes': 'Você não tem itens suficientes.',
    'a loja nao vende esse item': 'A loja não vende esse item.',
    'a loja nao compra esse item': 'A loja não compra esse item.',
    'isso nao se come': 'Isso não se come.',
    'quantidade invalida': 'Quantidade inválida.',
    'produto invalido': 'Produto inválido.',
    'saia da empresa atual antes': 'Saia da empresa em que trabalha antes de fundar outra.',
    'lote invalido': 'Lote inválido.',
    'lote ja vendido': 'Esse lote já foi vendido.',
    'tipo invalido': 'Tipo de empresa inválido.',
    'nome invalido': 'Nome inválido (3 a 24 letras, números, espaço, . & -).',
    'nome de empresa em uso': 'Já existe uma empresa com esse nome.',
    'voce nao e dono de empresa': 'Você não é dono de empresa.',
    'sua empresa nao e desse tipo': 'Sua empresa não é desse tipo.',
    'valor invalido': 'Valor inválido.',
    'caixa insuficiente': 'O caixa da empresa não tem saldo suficiente.',
    'jogador banido': 'Esse jogador está banido.',
    'jogador ja trabalha em uma empresa': 'Esse jogador já trabalha em uma empresa.',
    'limite de funcionarios': 'Limite de 20 funcionários.',
    'o dono nao pode se demitir': 'O dono não pode se demitir.',
    'jogador nao e seu funcionario': 'Esse jogador não é seu funcionário.',
    'o dono nao pode sair da propria empresa': 'O dono não pode sair da própria empresa.',
    'voce nao trabalha em uma fabrica': 'Você não trabalha nesta fábrica.',
    'a empresa esta sem caixa para pagar': 'A empresa está sem caixa para pagar. Avise o dono.',
    'transportadora invalida': 'Transportadora inválida.',
    'frete invalido': 'Frete inválido (de 0 até o valor da caixa).',
    'estoque insuficiente': 'Estoque insuficiente.',
    'pedido indisponivel': 'Esse pedido não está mais disponível.',
    'ha caixas a caminho': 'Há caixas a caminho; espere chegarem.',
    'voce nao trabalha em uma transportadora': 'Você não trabalha em uma transportadora.',
    'voce ja esta carregando uma caixa': 'Você já está carregando uma caixa.',
    'todas as caixas ja foram retiradas': 'Todas as caixas desse pedido já saíram.',
    'voce nao esta carregando caixa de pedido': 'Você não está carregando caixa de pedido.',
    'limite de caminhoes': 'Limite de 5 caminhões por empresa.',
    'caminhao invalido': 'Caminhão inválido.',
    'caminhao em viagem': 'Esse caminhão está em viagem.',
    'missao indisponivel': 'Essa missão não está mais disponível.',
    'sua fabrica nao produz esse item': 'Sua fábrica não produz esse item.',
    'voce nao e dono dessa empresa': 'Você não é dono dessa empresa.',
    'limite de empresas': 'Limite de 5 empresas por dono.',
    'o dono ja trabalha na empresa': 'O dono já trabalha na empresa.',
    'nivel maximo': 'A empresa já está no nível máximo.',
    'limite de robos': 'Limite de robôs deste nível. Evolua a empresa para ter mais.',
    'so transportadoras ou empresas nivel 3 compram caminhao': 'Só transportadoras, grupos ou empresas nível 3 compram caminhão.',
    'escolha duas empresas diferentes': 'Escolha duas empresas diferentes.',
    'fabricas de produtos diferentes': 'Não dá para fundir fábricas de produtos diferentes.',
    'termine os pedidos da empresa absorvida antes': 'Termine ou cancele os pedidos da empresa absorvida antes.',
    'ha caminhoes em viagem': 'Há caminhões em viagem; espere voltarem.',
    'policial nao rouba carga': 'Policial não rouba carga.',
    'caminhao sem carga': 'Esse caminhão não está levando carga.',
    'esse caminhao e seu': 'Esse caminhão é seu.',
    'quem tem crimes nao entra na policia': 'Quem está procurado não entra na polícia.',
    'a equipe nao entra na policia': 'A equipe não entra na polícia.',
    'saia do cla para entrar na policia': 'Saia do clã para entrar na polícia.',
    'voce nao esta em servico': 'Você não está em serviço.',
    'esse jogador nao e procurado': 'Esse jogador não é procurado.',
    'ja esta preso': 'Já está preso.',
    'voce nao esta preso': 'Você não está preso.',
    'policial nao entra em cla': 'Policial não entra em clã.',
    'voce ja esta em um cla': 'Você já está em um clã.',
    'nome de cla em uso': 'Já existe um clã com esse nome.',
    'voce nao e lider de cla': 'Só o líder do clã pode fazer isso.',
    'jogador ja esta em um cla': 'Esse jogador já está em um clã.',
    'limite de membros': 'Limite de 15 membros.',
    'o lider nao pode se expulsar': 'O líder não pode se expulsar.',
    'jogador nao e do seu cla': 'Esse jogador não é do seu clã.',
    'voce nao esta em um cla': 'Você não está em um clã.',
    'territorio invalido': 'Território inválido.',
    'o territorio ja e do seu cla': 'O território já é do seu clã.',
    'territorio recem capturado': 'Território recém-capturado; espere 3 minutos.',
    'captura nao iniciada': 'A captura não foi iniciada.',
    'captura incompleta': 'Ainda falta tempo para capturar.',
    'robos insuficientes': 'Robôs insuficientes.',
    'o territorio nao e do seu cla': 'O território não é do seu clã.',
    'voce ja tem uma casa': 'Você já tem uma casa.',
    'casa invalida': 'Casa inválida.',
    'casa ja vendida': 'Essa casa já tem dono.',
    'voce nao tem casa': 'Você não tem casa.',
    'bau cheio': 'O baú está cheio (200 de cada item).',
  };
  const espera = /^aguarde (\d+) s$/.exec(m);
  if (espera) return `Aguarde ${espera[1]} s.`;
  return t[m] || m;
}
export const painel = {
  moedas: (alvo, valor) => rpc('admin_moedas', { alvo, valor }),
  banir: (alvo, motivo) => rpc('admin_banir', { alvo, motivo }),
  desbanir: (alvo) => rpc('admin_desbanir', { alvo }),
  algemar: (alvo, ligado) => rpc('admin_algemar', { alvo, ligado }),
  prender: (alvo, minutos) => rpc('admin_prender', { alvo, minutos }),
  teleporte: (alvo, x, z) => rpc('admin_teleporte', { alvo, x, z }),
  definirCargo: (alvo, novo_cargo, novos_poderes, novo_salario) => rpc('admin_definir_cargo', { alvo, novo_cargo, novos_poderes, novo_salario }),
  skin: (novo) => rpc('staff_skin', { novo }),
  imortal: (ligado) => rpc('staff_imortal', { ligado }),
};
export const cumprirPena = () => rpc('cumprir_pena');
export const receberSalario = () => rpc('receber_salario');

export async function buscarJogadores(texto) {
  let q = sb.from('perfis').select('id,nome,cargo,personagem,moedas,banido,banido_motivo,algemado,pena_seg,poderes,salario,visto_em').order('nome').limit(40);
  if (texto) q = q.ilike('nome', `%${texto.replace(/[%_]/g, '')}%`);
  const { data, error } = await q;
  if (error) throw new Error(error.message);
  return data;
}
export async function listarEquipe() {
  const { data, error } = await sb.from('perfis').select('id,nome,cargo,poderes,salario').neq('cargo', 'jogador').order('nome');
  if (error) throw new Error(error.message);
  return data;
}
export async function historico() {
  const { data, error } = await sb.from('registro_admin').select('acao,detalhes,criado_em,autor:perfis!registro_admin_autor_fkey(nome),alvo:perfis!registro_admin_alvo_fkey(nome)').order('criado_em', { ascending: false }).limit(40);
  if (error) throw new Error(error.message);
  return data;
}

// ---------------------------------------------------------------- economia (etapa 3)
export const economia = {
  coletarSucata: () => rpc('coletar_sucata'),
  iniciarEmbalagem: (produto) => rpc('iniciar_embalagem', { produto }),
  entregarPacote: () => rpc('entregar_pacote'),
  comprar: (item, qtd) => rpc('comprar', { nome_item: item, quantidade: qtd }),
  vender: (item, qtd) => rpc('vender', { nome_item: item, quantidade: qtd }),
  consumir: (item) => rpc('consumir', { nome_item: item }),
};
export async function carregarPrecos() {
  const { data, error } = await sb.from('precos').select('*').order('item');
  if (error) throw new Error(error.message);
  return data;
}
export async function carregarInventario(id) {
  const { data, error } = await sb.from('inventario').select('item,qtd').eq('dono', id);
  if (error) throw new Error(error.message);
  const inv = {}; for (const r of data) inv[r.item] = r.qtd;
  return inv;
}

// ---------------------------------------------------------------- logística (etapa 4)
export const logistica = {
  comprarLote: (lote, nome, tipo, produto) => rpc('comprar_lote', { p_lote: lote, p_nome: nome, p_tipo: tipo, p_produto: produto }),
  depositar: (empresa, valor) => rpc('empresa_depositar', { p_empresa: empresa, valor }),
  sacar: (empresa, valor) => rpc('empresa_sacar', { p_empresa: empresa, valor }),
  pagamento: (empresa, valor) => rpc('empresa_pagamento', { p_empresa: empresa, valor }),
  contratar: (empresa, nome) => rpc('contratar', { p_empresa: empresa, p_nome: nome }),
  demitir: (empresa, jogador) => rpc('demitir', { p_empresa: empresa, p_jogador: jogador }),
  sair: () => rpc('sair_empresa'),
  embalar: (empresa) => rpc('embalar_fabrica', { p_empresa: empresa }),
  evoluir: (empresa) => rpc('evoluir_empresa', { p_empresa: empresa }),
  comprarRobo: (empresa) => rpc('comprar_robo', { p_empresa: empresa }),
  alugarRobo: (empresa) => rpc('alugar_robo', { p_empresa: empresa }),
  fundir: (principal, absorvida) => rpc('fundir_empresas', { p_principal: principal, p_absorvida: absorvida }),
  criarPedido: (fabrica, transportadora, qtd, frete) => rpc('criar_pedido', { p_fabrica: fabrica, p_transportadora: transportadora, p_qtd: qtd, p_frete: frete }),
  responder: (pedido, aceitar) => rpc('responder_pedido', { p_pedido: pedido, aceitar }),
  cancelar: (pedido) => rpc('cancelar_pedido', { p_pedido: pedido }),
  retirar: (pedido) => rpc('retirar_caixa', { p_pedido: pedido }),
  entregar: () => rpc('entregar_caixa'),
  desistir: () => rpc('desistir_caixa'),
  comprarCaminhao: (empresa) => rpc('comprar_caminhao', { p_empresa: empresa }),
  despachar: (caminhao, pedido, escolta = false) => rpc('despachar_caminhao', { p_caminhao: caminhao, p_pedido: pedido, p_escolta: escolta }),
  processar: () => rpc('processar_caminhoes'),
  missoes: () => rpc('listar_missoes'),
  aceitarMissao: (missao, fabrica, transportadora, frete) => rpc('aceitar_missao', { p_missao: missao, p_fabrica: fabrica, p_transportadora: transportadora, p_frete: frete }),
  agora: () => rpc('agora'),
  abrirFilial: (empresa, lote, funcao) => rpc('abrir_filial', { p_empresa: empresa, p_lote: lote, p_funcao: funcao }),
};
export const precoRobo = (empresa = null) => rpc('preco_robo', { p_excluir: empresa });
export const mercadoRobos = () => rpc('mercado_robos');
async function sel(q) { const { data, error } = await q; if (error) throw new Error(error.message); return data; }
export const listarEmpresas = () => sel(sb.from('empresas').select('*, dono_perfil:perfis!empresas_dono_fkey(nome)').order('id'));
export const listarCaminhoes = () => sel(sb.from('caminhoes').select('*').order('id'));
export const listarUnidades = () => sel(sb.from('unidades').select('*'));
export const listarMercado = () => sel(sb.from('mercado').select('*'));
export async function minhaEmpresaId(id) {
  const d = await sel(sb.from('membros').select('empresa').eq('jogador', id).maybeSingle());
  return d?.empresa ?? null;
}
export const membrosDe = (empresa) => sel(sb.from('membros').select('jogador, desde, perfil:perfis!membros_jogador_fkey(nome)').eq('empresa', empresa).order('desde'));
export const pedidosDe = (empresa) => sel(sb.from('pedidos')
  .select('*, fab:empresas!pedidos_fabrica_fkey(nome,lote), tra:empresas!pedidos_transportadora_fkey(nome)')
  .or(`fabrica.eq.${empresa},transportadora.eq.${empresa}`).order('id', { ascending: false }).limit(30));
export const pedidosAceitosDe = (transportadora) => sel(sb.from('pedidos').select('*, fab:empresas!pedidos_fabrica_fkey(nome,lote)')
  .eq('transportadora', transportadora).eq('status', 'aceito').order('id'));

// mudanças públicas: prédios, caminhões, equipe e pedidos
export function escutarLogistica(eventos) {
  const canal = sb.channel('logistica')
    .on('postgres_changes', { event: '*', schema: 'public', table: 'empresas' }, (p) => eventos.empresa?.(p))
    .on('postgres_changes', { event: '*', schema: 'public', table: 'caminhoes' }, (p) => eventos.caminhao?.(p))
    .on('postgres_changes', { event: '*', schema: 'public', table: 'membros' }, (p) => eventos.membro?.(p))
    .on('postgres_changes', { event: '*', schema: 'public', table: 'pedidos' }, (p) => eventos.pedido?.(p))
    .on('postgres_changes', { event: '*', schema: 'public', table: 'unidades' }, (p) => eventos.unidade?.(p))
    .on('postgres_changes', { event: '*', schema: 'public', table: 'territorios' }, (p) => eventos.territorio?.(p))
    .on('postgres_changes', { event: '*', schema: 'public', table: 'casas' }, (p) => eventos.casa?.(p))
    .on('postgres_changes', { event: '*', schema: 'public', table: 'clas' }, (p) => eventos.cla?.(p))
    .subscribe();
  return () => sb.removeChannel(canal);
}

// ---------------------------------------------------------------- combate, polícia, clãs e casas (etapas 5 a 7)
export const combate = {
  agressao: (alvo) => rpc('registrar_agressao', { p_alvo: alvo }),
  morrer: (assassino) => rpc('morrer', { p_assassino: assassino }),
  atacarCaminhao: (id) => rpc('atacar_caminhao', { p_caminhao: id }),
  usarRemedio: () => rpc('usar_remedio'),
};
export const policia = {
  entrar: () => rpc('entrar_policia'),
  sair: () => rpc('sair_policia'),
  salario: () => rpc('receber_salario_policia'),
  prender: (alvo) => rpc('prender_suspeito', { p_alvo: alvo }),
  fianca: () => rpc('pagar_fianca'),
};
export const cla = {
  evoluir: () => rpc('cla_evoluir'),
  criar: (nome, cor) => rpc('criar_cla', { p_nome: nome, p_cor: cor }),
  adicionar: (nome) => rpc('cla_adicionar', { p_nome: nome }),
  expulsar: (jogador) => rpc('cla_expulsar', { p_jogador: jogador }),
  sair: () => rpc('cla_sair'),
  depositar: (valor) => rpc('cla_depositar', { valor }),
  sacar: (valor) => rpc('cla_sacar', { valor }),
  comprarRobo: () => rpc('cla_comprar_robo'),
  retirar: (item, qtd) => rpc('cla_retirar', { p_item: item, p_qtd: qtd }),
  vender: (item, qtd) => rpc('cla_vender', { p_item: item, p_qtd: qtd }),
  iniciarCaptura: (t) => rpc('iniciar_captura', { p_territorio: t }),
  concluirCaptura: (t) => rpc('concluir_captura', { p_territorio: t }),
  atacar: (t, robos) => rpc('atacar_territorio', { p_territorio: t, p_robos: robos }),
  defender: (t, robos) => rpc('defender_territorio', { p_territorio: t, p_robos: robos }),
  processar: () => rpc('processar_territorios'),
};
export const casas = {
  comprar: (id) => rpc('comprar_casa', { p_casa: id }),
  guardar: (item, qtd) => rpc('guardar_no_bau', { p_item: item, p_qtd: qtd }),
  retirar: (item, qtd) => rpc('retirar_do_bau', { p_item: item, p_qtd: qtd }),
  vender: () => rpc('vender_casa'),
};
export async function listarBau(casa) {
  const d = await sel(sb.from('bau').select('item, qtd').eq('casa', casa));
  const b = {}; for (const r of d) b[r.item] = r.qtd; return b;
}
export const perdoar = (alvo) => rpc('admin_perdoar', { alvo });
export const listarClas = () => sel(sb.from('clas').select('*, lider_perfil:perfis!clas_lider_fkey(nome)').order('id'));
export const membrosDoCla = (id) => sel(sb.from('membros_cla').select('jogador, desde, perfil:perfis!membros_cla_jogador_fkey(nome)').eq('cla', id).order('desde'));
export async function meuClaId(id) { const d = await sel(sb.from('membros_cla').select('cla').eq('jogador', id).maybeSingle()); return d?.cla ?? null; }
export const listarTerritorios = () => sel(sb.from('territorios').select('*').order('id'));
export const listarCasas = () => sel(sb.from('casas').select('id, x, z, preco, dono, dono_perfil:perfis!casas_dono_fkey(nome)').order('id'));
